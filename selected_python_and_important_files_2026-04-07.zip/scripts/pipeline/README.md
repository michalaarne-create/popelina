# Pipeline Architecture

## Cel
Warstwa `scripts/pipeline` orkiestruje jedną iterację oraz pętlę uruchomień bez mieszania logiki OCR/DOM/brain w `main.py`.

## Przepływ iteracji
1. `stage_capture.capture_iteration_image(...)`
2. `stage_hover.run_hover_stage(...)`
3. `stage_region_rating.run_region_and_rating(...)`
4. `debuggers.files_reader.collect_and_dispatch_to_brain(...)`
5. `stage_brain_action.run_brain_action(...)`

Koordynacja całości:
- `iteration_orchestrator.run_iteration(...)`
- `loop_controller.run_loop(...)`

## Kontrakty
`contracts.py`:
- `PipelineConfig`
- `IterationInput`
- `IterationResult`

## Kompatybilność
- Stabilne API pozostaje w `scripts/pipeline/pipeline.py::pipeline_iteration(...)`.
- `main.py` używa kompatybilnych wrapperów i przekazuje zależności przez `deps` do orchestratora.
