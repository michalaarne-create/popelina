from __future__ import annotations

import contextlib
import time
import os
import threading
from pathlib import Path
from typing import Optional

from scripts.debuggers.files_reader import collect_and_dispatch_to_brain
from .contracts import IterationResult
from .stage_brain_action import run_brain_action
from .stage_capture import capture_iteration_image
from .stage_hover import run_hover_stage
from .stage_region_rating import run_region_and_rating


def run_iteration(
    *,
    loop_idx: int,
    screenshot_prefix: str,
    input_image: Optional[Path],
    fast_skip: bool,
    deps: dict,
) -> IterationResult:
    deps["globals_fn"]()["_iteration_in_progress"] = True
    final_json_path: Optional[Path] = None
    final_screenshot_path: Optional[Path] = None
    final_summary_path: Optional[Path] = None
    decision_action: Optional[str] = None
    rating_ok = False
    result_metadata: dict[str, object] = {
        "status": "started",
        "aborted": False,
        "fast_skip": bool(fast_skip),
    }
    def _is_abort_requested() -> bool:
        try:
            return bool(deps["globals_fn"]().get("_abort_iteration_requested"))
        except Exception:
            return False

    def _clear_abort_requested() -> None:
        try:
            deps["globals_fn"]()["_abort_iteration_requested"] = False
        except Exception:
            pass

    def _abort_iteration() -> None:
        deps["log"]("[WARN] Iteration aborted by hotkey '\"'.")
        deps["update_overlay_status"]("Iteration aborted.")
        _clear_abort_requested()

    deps["globals_fn"]()["_hover_fallback_allowed"] = True
    ts_iter = time.strftime("%Y%m%d_%H%M%S")
    os.environ["FULLBOT_OCR_ITERATION_ID"] = f"iter_{int(loop_idx)}_{ts_iter}"
    t_iter_start = time.perf_counter()
    if _is_abort_requested():
        _abort_iteration()
        result_metadata["status"] = "aborted_before_capture"
        result_metadata["aborted"] = True
        return IterationResult(
            loop_idx=loop_idx,
            screenshot_path=None,
            region_json_path=None,
            summary_path=None,
            decision_action=None,
            rating_ok=False,
            elapsed_s=time.perf_counter() - t_iter_start,
            metadata=result_metadata,
        )

    t_capture = time.perf_counter()
    screenshot_path = capture_iteration_image(
        loop_idx=loop_idx,
        screenshot_prefix=screenshot_prefix,
        input_image=input_image,
        screenshot_dir=deps["SCREENSHOT_DIR"],
        raw_current_dir=deps["RAW_CURRENT_DIR"],
        current_run_dir=deps["CURRENT_RUN_DIR"],
        capture_fullscreen=deps["capture_fullscreen"],
        write_current_artifact=deps["write_current_artifact"],
        debug_mode=bool(deps.get("DEBUG_MODE", False)),
        debug=deps["debug"],
        log=deps["log"],
        update_overlay_status=deps["update_overlay_status"],
    )
    deps["log"](f"[TIMER] iter.capture {time.perf_counter() - t_capture:.3f}s")
    if screenshot_path is None:
        result_metadata["status"] = "capture_missing"
        return IterationResult(
            loop_idx=loop_idx,
            screenshot_path=None,
            region_json_path=None,
            summary_path=None,
            decision_action=None,
            rating_ok=False,
            elapsed_s=time.perf_counter() - t_iter_start,
            metadata=result_metadata,
        )
    if _is_abort_requested():
        _abort_iteration()
        result_metadata["status"] = "aborted_after_capture"
        result_metadata["aborted"] = True
        final_screenshot_path = screenshot_path
        return IterationResult(
            loop_idx=loop_idx,
            screenshot_path=final_screenshot_path,
            region_json_path=None,
            summary_path=None,
            decision_action=None,
            rating_ok=False,
            elapsed_s=time.perf_counter() - t_iter_start,
            metadata=result_metadata,
        )

    t_hover = time.perf_counter()
    hover_image = run_hover_stage(
        screenshot_path=screenshot_path,
        prepare_hover_image=deps["prepare_hover_image"],
        log=deps["log"],
    )
    hover_early_async = str(os.environ.get("FULLBOT_HOVER_EARLY_ASYNC", "1") or "1").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    if hover_early_async and isinstance(hover_image, Path):
        try:
            hover_task = deps["run_hover_bot"](
                hover_image,
                screenshot_path.stem,
                start_time=t_iter_start,
            )
            deps["log"]("[INFO] Early hover async started (OCR -> hover).")
            if hover_task is not None:
                def _finalize():
                    try:
                        deps["finalize_hover_bot"](hover_task)
                    except Exception as exc:
                        deps["log"](f"[WARN] finalize_hover_bot failed: {exc}")
                t_fin = threading.Thread(target=_finalize, name="hover_finalize", daemon=True)
                t_fin.start()
        except Exception as exc:
            deps["log"](f"[WARN] Early hover async start failed: {exc}")
    deps["log"](f"[TIMER] iter.hover {time.perf_counter() - t_hover:.3f}s")
    if _is_abort_requested():
        _abort_iteration()
        result_metadata["status"] = "aborted_after_hover"
        result_metadata["aborted"] = True
        final_screenshot_path = screenshot_path
        return IterationResult(
            loop_idx=loop_idx,
            screenshot_path=final_screenshot_path,
            region_json_path=None,
            summary_path=None,
            decision_action=None,
            rating_ok=False,
            elapsed_s=time.perf_counter() - t_iter_start,
            metadata=result_metadata,
        )

    try:
        t_region_rating = time.perf_counter()
        json_path, rating_ok = run_region_and_rating(
            screenshot_path=screenshot_path,
            fast_skip=fast_skip,
            downscale_for_region=deps["downscale_for_region"],
            run_region_grow=deps["run_region_grow"],
            build_hover_from_region_results=deps["build_hover_from_region_results"],
            dispatch_hover_to_control_agent=deps["dispatch_hover_to_control_agent"],
            run_arrow_post=deps["run_arrow_post"],
            run_rating=deps["run_rating"],
            log=deps["log"],
            update_overlay_status=deps["update_overlay_status"],
            is_abort_requested=_is_abort_requested,
        )
        deps["log"](f"[TIMER] iter.region_rating {time.perf_counter() - t_region_rating:.3f}s")
        if _is_abort_requested():
            _abort_iteration()
            result_metadata["status"] = "aborted_after_region_rating"
            result_metadata["aborted"] = True
            rating_ok = bool(rating_ok)
            return IterationResult(
                loop_idx=loop_idx,
                screenshot_path=screenshot_path,
                region_json_path=json_path,
                summary_path=None,
                decision_action=None,
                rating_ok=bool(rating_ok),
                elapsed_s=time.perf_counter() - t_iter_start,
                metadata=result_metadata,
            )
        final_json_path = json_path
        final_screenshot_path = screenshot_path
        rating_ok = bool(rating_ok)
        if not json_path or not rating_ok:
            result_metadata["status"] = "region_rating_incomplete"
            return IterationResult(
                loop_idx=loop_idx,
                screenshot_path=final_screenshot_path,
                region_json_path=final_json_path,
                summary_path=None,
                decision_action=None,
                rating_ok=bool(rating_ok),
                elapsed_s=time.perf_counter() - t_iter_start,
                metadata=result_metadata,
            )

        t_dispatch = time.perf_counter()
        dispatch = collect_and_dispatch_to_brain(
            screenshot_path=screenshot_path,
            json_path=json_path,
            rate_results_dir=deps["RATE_RESULTS_DIR"],
            rate_results_debug_dir=deps["RATE_RESULTS_DEBUG_DIR"],
            rate_results_current_dir=deps["RATE_RESULTS_CURRENT_DIR"],
            rate_results_debug_current_dir=deps["RATE_RESULTS_DEBUG_CURRENT_DIR"],
            rate_summary_dir=deps["RATE_SUMMARY_DIR"],
            rate_summary_current_dir=deps["RATE_SUMMARY_CURRENT_DIR"],
            write_current_artifact=deps["write_current_artifact"],
            brain_agent=deps["BRAIN_AGENT"],
            log=deps["log"],
        )
        deps["log"](f"[TIMER] iter.files_reader_dispatch {time.perf_counter() - t_dispatch:.3f}s")
        if dispatch is None:
            deps["update_overlay_status"]("rating completed (no summary).")
            result_metadata["status"] = "dispatch_missing"
            return IterationResult(
                loop_idx=loop_idx,
                screenshot_path=final_screenshot_path,
                region_json_path=final_json_path,
                summary_path=None,
                decision_action=None,
                rating_ok=True,
                elapsed_s=time.perf_counter() - t_iter_start,
                metadata=result_metadata,
            )
        final_summary_path = dispatch.summary_path
        if _is_abort_requested():
            _abort_iteration()
            result_metadata["status"] = "aborted_after_dispatch"
            result_metadata["aborted"] = True
            return IterationResult(
                loop_idx=loop_idx,
                screenshot_path=final_screenshot_path,
                region_json_path=final_json_path,
                summary_path=final_summary_path,
                decision_action=None,
                rating_ok=True,
                elapsed_s=time.perf_counter() - t_iter_start,
                metadata=result_metadata,
            )
        t_action = time.perf_counter()
        decision_action = str(
            getattr(dispatch.decision, "recommended_action", "")
            or getattr(dispatch.decision, "action", "")
            or ""
        ) or None
        run_brain_action(
            decision=dispatch.decision,
            summary_path=dispatch.summary_path,
            screenshot_path=screenshot_path,
            send_click_from_bbox=deps["send_click_from_bbox"],
            scroll_on_box=deps["scroll_on_box"],
            find_screenshot_for_summary=deps["find_screenshot_for_summary"],
            send_best_click=deps["send_best_click"],
            send_random_click=deps["send_random_click"],
            send_key=deps["send_key"],
            send_key_repeat=deps["send_key_repeat"],
            send_type=deps["send_type"],
            send_wait=deps["send_wait"],
            ensure_dom_fallback=deps.get("ensure_dom_fallback"),
            log=deps["log"],
            update_overlay_status=deps["update_overlay_status"],
        )
        deps["log"](f"[TIMER] iter.brain_action {time.perf_counter() - t_action:.3f}s")
        try:
            sync_fn = deps.get("sync_current_dirs_into_current_run")
            if callable(sync_fn):
                t_sync = time.perf_counter()
                copied = int(sync_fn() or 0)
                deps["log"](f"[TIMER] iter.sync_current_run {time.perf_counter() - t_sync:.3f}s files={copied}")
        except Exception as exc:
            deps["log"](f"[WARN] sync_current_run failed: {exc}")
        try:
            total_small = (time.perf_counter() - t_dispatch)
            budget_small_ms = float(os.environ.get("FULLBOT_STAGE_SMALL_IO_BUDGET_MS", "80") or 80.0)
            if total_small * 1000.0 > budget_small_ms:
                deps["log"](
                    f"[WARN] files_reader+brain budget exceeded: "
                    f"{total_small*1000.0:.1f}ms > {budget_small_ms:.1f}ms"
                )
        except Exception:
            pass
        result_metadata["status"] = "completed"
    finally:
        with_ocr_iter = os.environ.get("FULLBOT_OCR_ITERATION_ID")
        if with_ocr_iter:
            os.environ.pop("FULLBOT_OCR_ITERATION_ID", None)
        try:
            scheduled = False
            schedule_fn = deps.get("schedule_deferred_debug_render")
            if callable(schedule_fn) and final_json_path is not None and final_screenshot_path is not None:
                try:
                    scheduled = bool(schedule_fn(final_json_path, final_screenshot_path, loop_idx))
                except Exception as exc:
                    deps["log"](f"[WARN] Deferred debug schedule failed: {exc}")
                    scheduled = False
            if (not scheduled) and final_json_path is not None and final_screenshot_path is not None:
                annotate_fn = deps.get("run_region_annotation")
                if callable(annotate_fn):
                    annotate_fn(final_json_path, final_screenshot_path)
        except Exception as exc:
            deps["log"](f"[WARN] Deferred region annotation step failed: {exc}")
        try:
            deps["globals_fn"]()["_iteration_in_progress"] = False
        except Exception:
            pass
        deps["cancel_hover_fallback_timer"]()
        dt_iter = time.perf_counter() - t_iter_start
        deps["log"](f"[TIMER] iteration {loop_idx} total {dt_iter:.3f}s")
        try:
            iter_budget_ms = float(os.environ.get("FULLBOT_ITERATION_BUDGET_MS", "2000") or 2000.0)
        except Exception:
            iter_budget_ms = 2000.0
        if dt_iter * 1000.0 > iter_budget_ms:
            deps["log"](f"[WARN] iteration budget exceeded: {dt_iter*1000.0:.1f}ms > {iter_budget_ms:.1f}ms")
            # Guardrail: tighten runtime profile automatically for next iterations.
            os.environ["FULLBOT_HOVER_DEBUG_ARTIFACTS"] = "0"
            os.environ["FULLBOT_REGION_GROW_LOG_VERBOSITY"] = "summary"
            with contextlib.suppress(Exception):
                current_side = int(os.environ.get("RG_TARGET_SIDE_TURBO", "1280") or 1280)
                if current_side > 1280:
                    os.environ["RG_TARGET_SIDE_TURBO"] = str(max(1280, current_side - 128))
    return IterationResult(
        loop_idx=loop_idx,
        screenshot_path=final_screenshot_path,
        region_json_path=final_json_path,
        summary_path=final_summary_path,
        decision_action=decision_action,
        rating_ok=bool(rating_ok),
        elapsed_s=time.perf_counter() - t_iter_start,
        metadata=result_metadata,
    )
