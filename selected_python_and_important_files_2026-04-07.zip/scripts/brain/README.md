﻿# scripts/brain - mapa plikow

## Zasada
- `runtime/` = glowna sciezka wykonywania.
- `fallback/` = kod zapasowy/legacy, ale dalej zywy jesli jest referencjonowany.
- `shared/` = wspolne typy/model danych.
- `dead/` = kopie plikow z root przeznaczone do dalszej decyzji porzadkowej (NIC nie jest automatycznie usuwane).

## Root (aktualnie)
- `__init__.py` - eksportuje publiczne typy pakietu brain z `shared/types.py`.
- `actions.py` - wrapper kompatybilnosci do `fallback/question_flow/actions.py`.
- `agent_decider.py` - wrapper kompatybilnosci do `runtime/agent_decider.py`.
- `agent_state_io.py` - wrapper kompatybilnosci do `runtime/agent_state_io.py`.
- `agent_targets.py` - wrapper kompatybilnosci do `runtime/agent_targets.py`.
- `brain.py` - wrapper kompatybilnosci do `fallback/question_flow/brain.py`.
- `brain_pipeline_answers.py` - wrapper kompatybilnosci do `fallback/question_flow/brain_pipeline_answers.py`.
- `context_selector.py` - wrapper kompatybilnosci do `fallback/qa/context_selector.py`.
- `fusion.py` - wrapper kompatybilnosci do `fallback/fusion/fusion.py`.
- `fusion_build.py` - wrapper kompatybilnosci do `fallback/fusion/fusion_build.py`.
- `fusion_loader.py` - wrapper kompatybilnosci do `fallback/fusion/fusion_loader.py`.
- `fusion_match.py` - wrapper kompatybilnosci do `fallback/fusion/fusion_match.py`.
- `fusion_score.py` - wrapper kompatybilnosci do `fallback/fusion/fusion_score.py`.
- `pipeline_brain.py` - wrapper kompatybilnosci do `fallback/compat/pipeline_brain.py`.
- `pipeline_brain_agent.py` - wrapper kompatybilnosci do `runtime/pipeline_brain_agent.py`.
- `pipeline_state_builder.py` - wrapper kompatybilnosci do `runtime/pipeline_state_builder.py`.
- `pipeline_state_cli.py` - wrapper kompatybilnosci do `fallback/compat/pipeline_state_cli.py`.
- `profile_facts.py` - wrapper kompatybilnosci do `fallback/qa/profile_facts.py`.
- `qa_gateway.py` - wrapper kompatybilnosci do `fallback/qa/qa_gateway.py`.
- `qa_prompt.py` - wrapper kompatybilnosci do `fallback/qa/qa_prompt.py`.
- `questions.py` - wrapper kompatybilnosci do `fallback/question_flow/questions.py`.
- `question_utils.py` - wrapper kompatybilnosci do `fallback/question_flow/question_utils.py`.
- `session_memory.py` - wrapper kompatybilnosci do `fallback/qa/session_memory.py`.
- `types.py` - wrapper kompatybilnosci do `shared/types.py`.

## runtime/
- `runtime/agent_decider.py` - glowna logika `PipelineBrainAgent.decide(...)` i konstrukcja `BrainDecision`.
- `runtime/agent_state_io.py` - odczyt/zapis JSON state (`load_json`, `load_state`, `save_state`).
- `runtime/agent_targets.py` - wybor konkretnego elementu/bbox dla rekomendowanej akcji.
- `runtime/pipeline_state_builder.py` - budowa stanu braina z summary/question + hash pytania.
- `runtime/pipeline_brain_agent.py` - cienki facade runtime eksportujacy `PipelineBrainAgent` i `BrainDecision`.
- `runtime/__init__.py` - znacznik pakietu.

## shared/
- `shared/types.py` - dataclass/typy wspolne (Element, BrainDecision, QuestionCluster, itd.).
- `shared/__init__.py` - znacznik pakietu.

## fallback/compat/
- `fallback/compat/pipeline_brain.py` - legacy facade do `build_brain_state` + entrypoint kompatybilny.
- `fallback/compat/pipeline_state_cli.py` - stary CLI do generowania stanu braina z plikow.
- `fallback/compat/__init__.py` - znacznik pakietu.

## fallback/fusion/
- `fallback/fusion/fusion.py` - publiczny punkt skladania fusion (re-export funkcji skladowych).
- `fallback/fusion/fusion_loader.py` - ladowanie i normalizacja danych DOM/rating do fusion.
- `fallback/fusion/fusion_match.py` - dopasowanie elementow (IoU, similarity, match reguly).
- `fallback/fusion/fusion_score.py` - scoring sygnalow i laczenie wynikow.
- `fallback/fusion/fusion_build.py` - budowanie finalnych elementow fused + hints.
- `fallback/fusion/__init__.py` - znacznik pakietu.

## fallback/qa/
- `fallback/qa/qa_gateway.py` - bramka QA: skladanie kontekstu i obsluga zapytan.
- `fallback/qa/qa_prompt.py` - budowanie promptu i mapowania etykiet/opcji.
- `fallback/qa/context_selector.py` - wybiera kontekst z memory/profile pod QA.
- `fallback/qa/session_memory.py` - magazyn pamieci sesyjnej (odczyt/zapis historii).
- `fallback/qa/profile_facts.py` - magazyn faktow/profilu uzytkownika.
- `fallback/qa/__init__.py` - znacznik pakietu.

## fallback/question_flow/
- `fallback/question_flow/brain.py` - starszy orchestrator krokow pytanie->decyzja.
- `fallback/question_flow/actions.py` - translacja decyzji na akcje UI/klik/scroll.
- `fallback/question_flow/questions.py` - budowanie klastrow pytan/opcji z elementow.
- `fallback/question_flow/question_utils.py` - helpery normalizacji/kluczy i obrobki pytan.
- `fallback/question_flow/brain_pipeline_answers.py` - pomocnicze pipeline answers oparte o decyzje brain.
- `fallback/question_flow/__init__.py` - znacznik pakietu.

## dead/
- `dead/*.py` - kopie dawnych plikow root (wrappery kompatybilnosci), zachowane na prosbe "nie usuwaj".
- `dead` nie jest wykonywany w glownej sciezce runtime.

## Narzedzia
- `tools/brain_dead_candidates.py` - raportuje kandydatow dead na podstawie referencji.
- raport wyjsciowy:
  - `scripts/brain/dead_candidates_report.json`
  - `scripts/brain/dead_candidates_report.txt`
