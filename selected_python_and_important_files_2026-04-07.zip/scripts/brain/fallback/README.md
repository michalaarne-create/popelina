﻿# Brain Fallback Modules

Ten katalog zawiera fallback/legacy moduly brain.
Nie sa traktowane jako martwe, jesli istnieja referencje wykonawcze
(import, re-export, CLI entrypoint, dynamiczne ladowanie).
