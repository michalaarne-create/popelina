﻿from __future__ import annotations

import contextlib
import os
import threading
import time
from typing import Any, Optional


def start_hotkey_listener(
    event: Any,
    command_queue: Any,
    *,
    log,
    debug,
    update_overlay_status,
    globals_fn,
    is_debug_mode,
    soft_exit_fn=None,
    full_exit_fn=None,
) -> Optional[Any]:
    try:
        from pynput import keyboard  # type: ignore
    except Exception as exc:
        log(f"[WARN] Hotkey listener unavailable (pynput import failed: {exc}). Falling back to auto mode.")
        return None

    pressed_chars: set[str] = set()
    pressed_lock = threading.Lock()
    brace_seq_armed_at: Optional[float] = None

    def _char_from_key(key: Any) -> Optional[str]:
        with contextlib.suppress(Exception):
            ch = getattr(key, "char", None)
            if isinstance(ch, str) and ch:
                return ch.lower()
        return None

    def on_press(key):
        nonlocal brace_seq_armed_at
        ch = _char_from_key(key)
        if ch is None:
            return
        with pressed_lock:
            if ch in pressed_chars:
                return
            pressed_chars.add(ch)
        if ch == "p":
            globals_fn()["_hover_fallback_allowed"] = True
            log("[INFO] Hotkey 'P' pressed - starting pipeline.")
            if bool(is_debug_mode()):
                debug("Hotkey P captured by listener, setting trigger_event.")
            event.set()
            update_overlay_status("Hotkey 'P' pressed - pipeline starting.")
        elif ch == "o":
            log("[INFO] Hotkey 'O' pressed - manual region_grow.")
            update_overlay_status("Hotkey 'O' pressed - region_grow queued.")
            command_queue.put("region")
        elif ch == "l":
            log("[INFO] Hotkey 'L' pressed - recorder launch requested.")
            update_overlay_status("Hotkey 'L' pressed - recorder queued.")
            command_queue.put("recorder")
        elif ch == "i":
            log("[INFO] Hotkey 'I' pressed - manual rating.")
            update_overlay_status("Hotkey 'I' pressed - rating queued.")
            command_queue.put("rating")
        elif ch == "k":
            log("[INFO] Hotkey 'K' pressed - control agent best click.")
            update_overlay_status("Hotkey 'K' pressed - control agent queued.")
            command_queue.put("control")
        elif ch == '"':
            if bool(globals_fn().get("_iteration_in_progress")):
                globals_fn()["_abort_iteration_requested"] = True
                command_queue.put("abort")
                log("[WARN] Hotkey '\"' pressed - aborting current iteration.")
                update_overlay_status("Abort requested for current iteration.")
            else:
                log("[INFO] Hotkey '\"' ignored (no active iteration).")
        elif ch == "}":
            now = time.time()
            if brace_seq_armed_at is not None and (now - brace_seq_armed_at) <= 0.8:
                log("[WARN] Full exit requested via '{}' hotkey sequence.")
                if callable(full_exit_fn):
                    try:
                        full_exit_fn()
                    finally:
                        os._exit(0)
                os._exit(0)
            log("[WARN] Soft exit requested via '}' hotkey.")
            if callable(soft_exit_fn):
                try:
                    soft_exit_fn()
                finally:
                    os._exit(0)
            os._exit(0)
        elif ch == "{":
            brace_seq_armed_at = time.time()

    def on_release(key):
        ch = _char_from_key(key)
        if ch is None:
            return
        with pressed_lock:
            pressed_chars.discard(ch)

    listener = keyboard.Listener(on_press=on_press, on_release=on_release)
    listener.daemon = True
    listener.start()
    log("[INFO] Hotkeys: P=pipeline, O=region_grow, L=recorder, I=rating, K=control agent, \"=abort iteration, }=soft exit, {}=full exit.")
    update_overlay_status("Hotkeys ready (P/O/L/I/K/\").")
    return listener


def start_early_exit_listener(
    *,
    log,
    soft_exit_fn=None,
    full_exit_fn=None,
) -> Optional[Any]:
    try:
        from pynput import keyboard  # type: ignore
    except Exception:
        return None

    brace_seq_armed_at: Optional[float] = None

    def _char_from_key(key: Any) -> Optional[str]:
        with contextlib.suppress(Exception):
            ch = getattr(key, "char", None)
            if isinstance(ch, str) and ch:
                return ch.lower()
        return None

    def on_press(key):
        nonlocal brace_seq_armed_at
        ch = _char_from_key(key)
        if ch is None:
            return
        if ch == "{":
            brace_seq_armed_at = time.time()
            return
        if ch != "}":
            return
        now = time.time()
        if brace_seq_armed_at is not None and (now - brace_seq_armed_at) <= 0.8:
            log("[WARN] Full exit requested via '{}' hotkey sequence (early listener).")
            if callable(full_exit_fn):
                with contextlib.suppress(Exception):
                    full_exit_fn()
            os._exit(0)
        log("[WARN] Soft exit requested via '}' hotkey (early listener).")
        if callable(soft_exit_fn):
            with contextlib.suppress(Exception):
                soft_exit_fn()
        os._exit(0)

    listener = keyboard.Listener(on_press=on_press)
    listener.daemon = True
    listener.start()
    return listener


def wait_for_p_in_console() -> None:
    if os.name == "nt":
        try:
            import msvcrt  # type: ignore

            while True:
                ch = msvcrt.getwch()
                if isinstance(ch, str) and ch.lower() == "p":
                    return
        except Exception:
            pass
    while True:
        line = input("Press P + Enter to run one iteration: ").strip().lower()
        if line == "p":
            return
