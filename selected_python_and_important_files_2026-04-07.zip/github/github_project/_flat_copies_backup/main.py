﻿#!/usr/bin/env python3
"""
Main orchestrator for the live dropdown pipeline.

It launches the Chrome recorder (ai_recorder_live) once and then, every
PIPELINE_INTERVAL seconds, captures the full screen, runs scripts/region_grow/region_grow/region_grow.py
on the screenshot (region_grow already performs OCR internally) and finally
feeds the JSON emitted by region_grow into scripts/region_grow/numpy_rate/rating.py.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import contextlib
import importlib.util
import io
import json
import math
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple, TYPE_CHECKING

from PIL import Image

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scripts.brain.runtime.pipeline_brain_agent import BrainDecision, PipelineBrainAgent
from scripts.click.hover import hover_runtime as _hover_runtime
from scripts.debuggers.files_reader import collect_and_dispatch_to_brain as _collect_and_dispatch_to_brain
from scripts.overlay.console_overlay import colorize_log_message, init_console_overlay
from scripts.pipeline.cli_args import parse_args as _parse_args_mod
from scripts.pipeline.hotkeys import (
    start_early_exit_listener as _start_early_exit_listener_mod,
    start_hotkey_listener as _start_hotkey_listener_mod,
    wait_for_p_in_console as _wait_for_p_in_console_mod,
)
from scripts.pipeline.iteration_orchestrator import run_iteration as _run_iteration_orchestrator
from scripts.pipeline.loop_controller import run_loop as _run_loop_controller
from scripts.pipeline.manual_commands import (
    drain_manual_commands as _drain_manual_commands_mod,
    handle_manual_command as _handle_manual_command_mod,
)
from scripts.pipeline.pipeline import pipeline_iteration as _pipeline_iteration_external
from scripts.pipeline.process_control import (
    ensure_control_agent as _ensure_control_agent_mod,
    start_ai_recorder as _start_ai_recorder_mod,
    stop_process as _stop_process_mod,
)
from scripts.pipeline.runtime_capture import (
    capture_fullscreen as _capture_fullscreen_mod,
    prepare_hover_image as _prepare_hover_image_mod,
)
from scripts.pipeline.runtime_clicks import (
    scroll_on_box as _scroll_on_box_mod,
    send_click_from_bbox as _send_click_from_bbox_mod,
)
from scripts.pipeline.runtime_click_summaries import (
    find_screenshot_for_summary as _find_screenshot_for_summary_mod,
    send_best_click as _send_best_click_mod,
    send_random_click as _send_random_click_mod,
)
from scripts.pipeline.runtime_region_rating import (
    bootstrap_region_grow_worker as _bootstrap_region_grow_worker_mod,
    is_region_grow_daemon_alive as _is_region_grow_daemon_alive_mod,
    latest_file as _latest_file_mod,
    run_region_annotation as _run_region_annotation_mod,
    run_arrow_post as _run_arrow_post_mod,
    run_rating as _run_rating_mod,
    run_region_grow as _run_region_grow_mod,
    stop_region_grow_daemon as _stop_region_grow_daemon_mod,
)
from scripts.pipeline.runtime_control_agent import (
    send_control_agent as _send_control_agent_mod,
    send_key as _send_key_mod,
    send_key_repeat as _send_key_repeat_mod,
    send_type as _send_type_mod,
    send_udp_payload as _send_udp_payload_mod,
    send_wait as _send_wait_mod,
)
from scripts.pipeline.runtime_hover_dispatch import (
    dispatch_hover_to_control_agent as _dispatch_hover_to_control_agent_mod,
)
from scripts.pipeline.runtime_deferred_debug import create_deferred_debug_worker
from scripts.pipeline.runtime_click_monitor import start_screen_click_monitor

if TYPE_CHECKING:
    import keyboard


def _load_register_main_launch():
    repo_root = Path(__file__).resolve().parent
    mod_path = repo_root / "github" / "git pusher" / "launch_git_automation.py"
    if not mod_path.exists():
        raise ModuleNotFoundError(f"Missing launch_git_automation at {mod_path}")
    spec = importlib.util.spec_from_file_location("launch_git_automation_dynamic", str(mod_path))
    if spec is None or spec.loader is None:
        raise ModuleNotFoundError(f"Cannot load module spec from {mod_path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    fn = getattr(mod, "register_main_launch", None)
    if not callable(fn):
        raise ModuleNotFoundError(f"register_main_launch not found in {mod_path}")
    return fn


register_main_launch = _load_register_main_launch()

ROOT = Path(__file__).resolve().parent
DATA_SCREEN_DIR = ROOT / "data" / "screen"
HOVER_DIR = ROOT / "data" / "screen" / "hover"
RAW_DIR = ROOT / "data" / "screen" / "raw"
AI_RECORDER_SCRIPT = ROOT / "scripts" / "dom" / "dom_renderer" / "ai_recorder_live.py"
REGION_GROW_SCRIPT = ROOT / "scripts" / "region_grow" / "region_grow" / "region_grow.py"
RATING_SCRIPT = ROOT / "scripts" / "region_grow" / "numpy_rate" / "rating.py"
ARROW_POST_SCRIPT = ROOT / "scripts" / "arrow_post_region.py"
HOVER_SINGLE_SCRIPT = ROOT / "scripts" / "click" / "hover" / "hover_single.py"
CONTROL_AGENT_SCRIPT = ROOT / "scripts" / "click" / "control_agent" / "control_agent.py"
QUIZ_SERVER_SCRIPT = Path(
    os.environ.get("FULLBOT_QUIZ_SERVER_SCRIPT", str(ROOT / "quiz" / "test_quiz_server.py"))
    or str(ROOT / "quiz" / "test_quiz_server.py")
)
QUIZ_SERVER_HOST = str(os.environ.get("FULLBOT_QUIZ_SERVER_HOST", "127.0.0.1") or "127.0.0.1")
QUIZ_SERVER_PORT = int(os.environ.get("FULLBOT_QUIZ_SERVER_PORT", "8000") or "8000")
QUIZ_SERVER_URL = f"http://{QUIZ_SERVER_HOST}:{QUIZ_SERVER_PORT}/"
RECORDER_PROFILE_DIR = ROOT / "_recorder_profile"
RECORDER_CDP_PORT = int(os.environ.get("FULLBOT_RECORDER_CDP_PORT", "9222"))
SCREENSHOT_DIR = ROOT / "data" / "screen" / "raw" / "raw screen"
SCREEN_BOXES_DIR = ROOT / "data" / "screen" / "numpy_points" / "screen_boxes"
DOM_LIVE_DIR = ROOT / "scripts" / "dom" / "dom_live"
CURRENT_PAGE_PATH = DOM_LIVE_DIR / "current_page.json"
CURRENT_CONTROLS_PATH = DOM_LIVE_DIR / "current_controls.json"
CURRENT_QUESTION_PATH = ROOT / "scripts" / "dom" / "dom_live" / "current_question.json"
CURRENT_RUN_DIR = ROOT / "data" / "screen" / "current_run"
ANSWERS_DIR = ROOT / "data" / "answers"
QUIZ_ANSWER_CACHE_DEFAULT = ANSWERS_DIR / "qa_cache.json"
REGION_GROW_BASE_DIR = ROOT / "data" / "screen" / "region_grow"
REGION_GROW_JSON_DIR = ROOT / "data" / "screen" / "region_grow" / "region_grow"
REGION_GROW_ANNOT_DIR = ROOT / "data" / "screen" / "region_grow" / "region_grow_annot"
REGION_GROW_ANNOT_CURRENT_DIR = ROOT / "data" / "screen" / "region_grow" / "region_grow_annot_current"
REGION_GROW_CURRENT_DIR = ROOT / "data" / "screen" / "region_grow" / "region_grow_current"
HOVER_INPUT_DIR = ROOT / "data" / "screen" / "hover" / "hover_input"
HOVER_OUTPUT_DIR = ROOT / "data" / "screen" / "hover" / "hover_output"
HOVER_INPUT_CURRENT_DIR = ROOT / "data" / "screen" / "hover" / "hover_input_current"
HOVER_OUTPUT_CURRENT_DIR = ROOT / "data" / "screen" / "hover" / "hover_output_current"
CLICKS_ON_SCREEN_DIR = ROOT / "data" / "screen" / "clicks_on_screen"
RAW_CURRENT_DIR = ROOT / "data" / "screen" / "raw" / "raw_screens_current"
HOVER_PATH_DIR = ROOT / "data" / "screen" / "hover" / "hover_path"
HOVER_PATH_CURRENT_DIR = ROOT / "data" / "screen" / "hover" / "hover_path_current"
HOVER_SPEED_DIR = ROOT / "data" / "screen" / "hover" / "hover_speed"
HOVER_SPEED_CURRENT_DIR = ROOT / "data" / "screen" / "hover" / "hover_speed_current"
HOVER_SPEED_RECORDER_SCRIPT = ROOT / "scripts" / "click" / "recorder" / "hover_speed_recorder.py"
HOVER_SIDE_CROP = 300
# Fixed browser top bar crop for all captures (tabs + URL bar).
SCREEN_TOP_CROP_PX = 78
# Hover input comes from already cropped screenshot; do not crop again.
HOVER_TOP_CROP = 0
SCREEN_CLICK_OFFSET_X = 0
SCREEN_CLICK_OFFSET_Y = SCREEN_TOP_CROP_PX
CONTROL_AGENT_PORT = int(os.environ.get("CONTROL_AGENT_PORT", "8765"))
HOVER_FALLBACK_SECONDS = float(os.environ.get("HOVER_FALLBACK_SECONDS", "10"))
REGION_GROW_TIMEOUT = float(os.environ.get("REGION_GROW_TIMEOUT", "45"))
HOVER_SPACING_X = float(os.environ.get("HOVER_SPACING_X", "1.0"))
OVERLAY_HIDE_BEFORE_SCREENSHOT_S = 0.25
OVERLAY_SHOW_AFTER_SCREENSHOT_S = 0.25
RATE_RESULTS_DIR = ROOT / "data" / "screen" / "rate" / "rate_results"
RATE_RESULTS_DEBUG_DIR = ROOT / "data" / "screen" / "rate" / "rate_results_debug"
RATE_SUMMARY_DIR = ROOT / "data" / "screen" / "rate" / "rate_summary"
RATE_RESULTS_CURRENT_DIR = ROOT / "data" / "screen" / "rate" / "rate_results_current"
RATE_RESULTS_DEBUG_CURRENT_DIR = ROOT / "data" / "screen" / "rate" / "rate_results_debug_current"
RATE_SUMMARY_CURRENT_DIR = ROOT / "data" / "screen" / "rate" / "rate_summary_current"
BRAIN_STATE_FILE = ROOT / "data" / "brain_state.json"

# Hardcoded debug config (without CLI flags) - split by area.
FORCE_DEBUG_CORE = True
FORCE_ADVANCED_DEBUG_CORE = False
FORCE_DEBUG_CONTROL_AGENT = False
FORCE_DEBUG_REGION_GROW = True
FORCE_DEBUG_RATING = True
FORCE_DEBUG_RATING_FAST = True
FORCE_DEBUG_OCR = True
FORCE_DEBUG_TIMERS = True


def _apply_debug_settings_from_args(args: argparse.Namespace) -> None:
    env_adv = str(os.environ.get("FULLBOT_ADVANCED_DEBUG", "0") or "0").strip().lower() in {"1", "true", "yes", "on"}
    env_dbg = str(os.environ.get("FULLBOT_DEBUG", "0") or "0").strip().lower() in {"1", "true", "yes", "on"}
    env_ca_dbg = str(os.environ.get("CONTROL_AGENT_VERBOSE", "0") or "0").strip().lower() in {"1", "true", "yes", "on"}

    if env_dbg:
        args.debug = True
    if env_adv:
        args.advanced_debug = True
    if env_ca_dbg:
        args.debug_control_agent = True

    # Hard override from code (requested: configure in code, not flags).
    if FORCE_DEBUG_CORE:
        args.debug = True
    if FORCE_ADVANCED_DEBUG_CORE:
        args.advanced_debug = True
    if FORCE_DEBUG_CONTROL_AGENT:
        args.debug_control_agent = True

    # DEBUG category
    if bool(getattr(args, "debug_control_agent", False)):
        os.environ["CONTROL_AGENT_VERBOSE"] = "1"

    # ADVANCED DEBUG category
    if bool(getattr(args, "advanced_debug", False)):
        os.environ["FULLBOT_ADVANCED_DEBUG"] = "1"
        args.debug = True
    # Per-area debug settings.
    if FORCE_DEBUG_CONTROL_AGENT or bool(getattr(args, "debug_control_agent", False)) or bool(getattr(args, "advanced_debug", False)):
        os.environ["CONTROL_AGENT_VERBOSE"] = "1"
    if FORCE_DEBUG_REGION_GROW or bool(getattr(args, "advanced_debug", False)):
        os.environ["RG_VERBOSE"] = "1"
    if FORCE_DEBUG_OCR or bool(getattr(args, "advanced_debug", False)):
        os.environ["FULLBOT_OCR_BOXES_DEBUG"] = "1"
    if FORCE_DEBUG_TIMERS or bool(getattr(args, "advanced_debug", False)):
        os.environ["FULLBOT_ENABLE_TIMERS"] = "1"
        globals()["ENABLE_TIMERS"] = True
    if FORCE_DEBUG_RATING or bool(getattr(args, "advanced_debug", False)):
        os.environ["FULLBOT_RATING_DEBUG"] = "1"
    if FORCE_DEBUG_RATING_FAST or bool(getattr(args, "advanced_debug", False)):
        os.environ["FULLBOT_RATING_FAST_DEBUG"] = "1"
        os.environ["FULLBOT_RATING_FAST_DEBUG_TIMERS"] = "1"
    if bool(getattr(args, "advanced_debug", False)) and os.name == "nt":
        # In advanced debug mode allow subprocesses (e.g. control_agent) to emit logs visibly.
        globals()["SUBPROCESS_KW"] = {}


# Global timer switch (1=ON, 0=OFF). Controls all "[TIMER]" logs.





ENABLE_TIMERS = str(os.environ.get("FULLBOT_ENABLE_TIMERS", "1") or "1").strip().lower() in {"1", "true", "yes", "on"}
LIGHT_INFO_DEBUG = str(os.environ.get("FULLBOT_LIGHT_INFO_DEBUG", "1") or "1").strip().lower() in {"1", "true", "yes", "on"}
_LIGHT_INFO_ALLOWLIST = (
    "Warming OCR models",
    "OCR warmup skipped",
    "Preloaded shared OCR",
    "OCR ready",
    "Bootstrapping region_grow worker",
    "region_grow worker ready",
    "Brain recommended",
    "Brain action",
    "Brain quiz parse:",
    "Brain recognized quiz:",
    "click at (",
    "next not detected",
    "No next",
    "Waiting for hotkey 'P'",
    "Waiting for 'P' (iteration",
)

if hasattr(os, "add_dll_directory"):
    candidate_dirs = [
        Path(sys.prefix) / "Library" / "bin",
        Path(sys.prefix) / "DLLs",
    ]
    for dll_dir in candidate_dirs:
        if dll_dir.exists():
            try:
                os.add_dll_directory(str(dll_dir))
            except Exception:
                pass
            os.environ["PATH"] = str(dll_dir) + os.pathsep + os.environ.get("PATH", "")
try:
    from scripts.click.hover import send_hover_path as _shp_defaults  # type: ignore

    HOVER_SPEED_DEFAULTS = {
        "speed": getattr(_shp_defaults, "DEFAULT_SPEED_MODE", "normal"),
        "speed_factor": float(getattr(_shp_defaults, "DEFAULT_SPEED_FACTOR", 1.0)),
        "min_dt": float(getattr(_shp_defaults, "DEFAULT_MIN_DT", 0.004)),
        "speed_px_per_s": float(getattr(_shp_defaults, "DEFAULT_SPEED_PX_PER_S", 740.0)),
        "gap_boost": float(getattr(_shp_defaults, "DEFAULT_GAP_BOOST", 1.4)),
        "line_jump_boost": float(getattr(_shp_defaults, "DEFAULT_LINE_JUMP_BOOST", 1.8)),
    }
except Exception:
    _shp_defaults = None
    HOVER_SPEED_DEFAULTS = {
        "speed": "normal",
        "speed_factor": 1.0,
        "min_dt": 0.004,
        "speed_px_per_s": 740.0,
        "gap_boost": 1.4,
        "line_jump_boost": 1.8,
    }
_IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp")
_JSON_EXTS = (".json",)
_turbo_default = str(os.environ.get("FULLBOT_TURBO_MODE", "1") or "1").strip().lower() in {"1", "true", "yes", "on"}
REGION_RESIZE_MAX_SIDE = int(os.environ.get("REGION_RESIZE_MAX_SIDE", "1920" if _turbo_default else "1920"))

CREATE_NO_WINDOW = 0
if os.name == "nt":
    CREATE_NO_WINDOW = 0x08000000
SUBPROCESS_KW = {"creationflags": CREATE_NO_WINDOW} if os.name == "nt" else {}
_hover_fallback_timer: Optional[threading.Timer] = None
_hover_fallback_allowed = False
_abort_iteration_requested = False
_iteration_in_progress = False
HOLD_LEFT_BUTTON = False
DEBUG_MODE = False
ADVANCED_DEBUG_MODE = False
_status_overlay = None
_hover_reader_cache = None
_region_grow_module = None
_ocr_warmed = False
_mss_singleton: Optional[object] = None
_rating_module = None
_deferred_debug_worker = None
_click_monitor = None
_dom_fallback_ensurer = None
_recorder_proc_ref = None


def ensure_dom_fallback(reason: str = "") -> bool:
    fn = globals().get("_dom_fallback_ensurer")
    if callable(fn):
        try:
            return bool(fn(str(reason or "")))
        except Exception:
            return False
    return False


_SUPPRESSED_PADDLE_LOG_SNIPPETS = (
    "Checking connectivity to the model hosters",
    "Connectivity check to the model hoster has been skipped",
    "Model files already exist. Using cached files.",
    "Creating model:",
    "No ccache found",
    "Logging before InitGoogleLogging()",
    "gpu_resources.cc:",
    "[OCR] debug ",
    "[OCR] runtime ready:",
    "[DEBUG] Shared OCR runtime initialized",
)

# Silence native Paddle/GLOG noise as early as possible.
os.environ.setdefault("GLOG_minloglevel", "3")
os.environ.setdefault("FLAGS_minlog_level", "3")
os.environ.setdefault("FLAGS_logtostderr", "0")
# Keep PaddleX model cache local to workspace to avoid user-profile ACL issues.
_pdx_cache_home = ROOT / ".paddlex_cache"
with contextlib.suppress(Exception):
    _pdx_cache_home.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("PADDLE_PDX_CACHE_HOME", str(_pdx_cache_home))
os.environ.setdefault("PADDLE_PDX_MODEL_SOURCE", "bos")
os.environ.setdefault("FULLBOT_QUIZ_ANSWER_CACHE", str(QUIZ_ANSWER_CACHE_DEFAULT))
# Keep brain in quiz pipeline mode by default (legacy mode returns idle/unknown on modern quiz screens).
os.environ.setdefault("FULLBOT_QUIZ_MODE", "1")
os.environ.setdefault("FULLBOT_TURBO_MODE", "1")
os.environ.setdefault("REGION_GROW_TURBO", "1")
os.environ.setdefault("FULLBOT_RUNTIME_PROFILE", "ultra_fast")
os.environ.setdefault("RATING_MODE", "heavy")
os.environ.setdefault("FULLBOT_REGION_RATING_BUDGET_MS", "1000")
os.environ.setdefault("REGION_GROW_MAX_SIDE_TURBO", "1920")
os.environ.setdefault("REGION_GROW_MAX_DETECTIONS_TURBO", "60")
os.environ.setdefault("FULLBOT_OCR_BOXES_DEBUG", "0")
os.environ.setdefault("FULLBOT_OCR_PIPELINE", "two_stage")
os.environ.setdefault("FULLBOT_OCR_STAGE1_BACKEND", "rapid_det")
os.environ.setdefault("FULLBOT_OCR_STAGE1_MAX_SIDE", "960")
os.environ.setdefault("FULLBOT_OCR_STAGE1_REQUIRE_RAPID", "1")
os.environ.setdefault("FULLBOT_OCR_STAGE1_USE_DET", "1")
os.environ.setdefault("FULLBOT_OCR_STAGE1_USE_CLS", "0")
os.environ.setdefault("FULLBOT_OCR_STAGE1_USE_REC", "0")
os.environ.setdefault("FULLBOT_OCR_STAGE1_DET_LIMIT_TYPE", "max")
os.environ.setdefault("FULLBOT_OCR_STAGE1_DET_LIMIT_SIDE_LEN", os.environ.get("FULLBOT_OCR_STAGE1_MAX_SIDE", "960"))
os.environ.setdefault("FULLBOT_OCR_STAGE1_DET_MAX_CANDIDATES", "300")
os.environ.setdefault("FULLBOT_OCR_STAGE1_WARMUP_RUNS", "2")
os.environ.setdefault("FULLBOT_DEBUG_DEFERRED_RENDER", "1")
os.environ.setdefault("FULLBOT_DEBUG_DEFERRED_DRAIN_ON_EXIT", "1")
os.environ.setdefault("FULLBOT_DEBUG_DEFERRED_QUEUE_MAX", "0")
os.environ.setdefault("FULLBOT_CAPTURE_ARCHIVE_EVERY_N", "0")
os.environ.setdefault("FULLBOT_HOVER_DEBUG_ARTIFACTS", "0")
os.environ.setdefault("FULLBOT_HOVER_ENABLED", "0")
os.environ.setdefault("FULLBOT_CLICK_MONITOR_ENABLED", "1")
# Master switch for launching recorder stack (CDP browser + ai_recorder).
# 1 = enable, 0 = disable both.
os.environ.setdefault("FULLBOT_ENABLE_RECORDER_STACK", "0")
os.environ.setdefault("FULLBOT_DOM_FALLBACK_ACTIVE", "0")
os.environ.setdefault("FULLBOT_DOM_FALLBACK_ON_DEMAND", "0")
os.environ.setdefault("FULLBOT_QUIZ_TYPE_MODEL_ENABLED", "1")
os.environ.setdefault("FULLBOT_QUIZ_TYPE_MIN_CONF", "0.45")
os.environ.setdefault("FULLBOT_QUIZ_TYPE_UNKNOWN_ENABLED", "1")
os.environ.setdefault("FULLBOT_QUIZ_TYPE_DOM_ASSIST", "0")
os.environ.setdefault("FULLBOT_QUIZ_TYPE_DEBUG", "0")
os.environ.setdefault("FULLBOT_QUIZ_TYPE_MODEL_PATH", str(ROOT / "data" / "models" / "quiz_type_classifier_v1.json"))
os.environ.setdefault("FULLBOT_ELEMENT_ROLE_MODEL_ENABLED", "1")
os.environ.setdefault("FULLBOT_ELEMENT_ROLE_MODEL_PATH", str(ROOT / "data" / "models" / "element_role_classifier_v2.json"))
os.environ.setdefault("FULLBOT_ELEMENT_ROLE_GUARDRAILS", "1")
os.environ.setdefault("FULLBOT_ITERATION_BUDGET_MS", "2000")
os.environ.setdefault("FULLBOT_STAGE_CAPTURE_BUDGET_MS", "180")
os.environ.setdefault("FULLBOT_STAGE_HOVER_BUDGET_MS", "120")
os.environ.setdefault("FULLBOT_STAGE_REGION_RATING_BUDGET_MS", "1550")
os.environ.setdefault("FULLBOT_REGION_USE_DOWNSCALED_IMAGE", "0")
os.environ.setdefault("FULLBOT_REGION_GROW_LOG_VERBOSITY", "summary")
os.environ.setdefault("REGION_GROW_ENABLE_REGIONS_EXPORT", "0")
os.environ.setdefault("FULLBOT_RATING_FORCE_SUBPROCESS", "0")
os.environ.setdefault("FULLBOT_RATING_DEBUG", "0")
os.environ.setdefault("RG_TARGET_SIDE_TURBO", "1280")
os.environ.setdefault("FULLBOT_LIGHT_INFO_DEBUG", "1")
# OCR rec batch on GPU (region_grow reads PADDLEOCR_REC_BATCH at import time).
# Override with FULLBOT_OCR_REC_BATCH or PADDLEOCR_REC_BATCH if needed.
os.environ.setdefault("PADDLEOCR_REC_BATCH", str(os.environ.get("FULLBOT_OCR_REC_BATCH", "48") or "48"))


def _apply_runtime_profile_defaults() -> None:
    profile = str(os.environ.get("FULLBOT_RUNTIME_PROFILE", "ultra_fast") or "ultra_fast").strip().lower()
    if profile != "ultra_fast":
        return
    os.environ.setdefault("FULLBOT_REGION_GROW_LOG_VERBOSITY", "summary")
    os.environ.setdefault("REGION_GROW_ENABLE_REGIONS_EXPORT", "0")
    os.environ.setdefault("FULLBOT_OCR_BOXES_DEBUG", "0")
    os.environ.setdefault("FULLBOT_DEBUG_DEFERRED_RENDER", "1")
    os.environ.setdefault("FULLBOT_REGION_USE_DOWNSCALED_IMAGE", "0")
    os.environ.setdefault("RG_TARGET_SIDE_TURBO", "1280")
    os.environ.setdefault("FULLBOT_CAPTURE_ARCHIVE_EVERY_N", "0")
    os.environ.setdefault("FULLBOT_HOVER_DEBUG_ARTIFACTS", "0")
    os.environ.setdefault("FULLBOT_RATING_FORCE_SUBPROCESS", "0")


_apply_runtime_profile_defaults()


class _FilterLineWriter(io.TextIOBase):
    """Forward stream writes but drop known noisy Paddle init lines."""

    def __init__(self, target: Any, suppressed_snippets: Tuple[str, ...]) -> None:
        super().__init__()
        self._target = target
        self._suppressed = tuple(str(s) for s in suppressed_snippets if str(s))
        self._buf = ""

    def writable(self) -> bool:
        return True

    def write(self, s: str) -> int:
        text = str(s or "")
        if not text:
            return 0
        self._buf += text
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            full = line + "\n"
            plain = re.sub(r"\x1b\[[0-9;]*m", "", full)
            if any(sn in plain for sn in self._suppressed):
                continue
            with contextlib.suppress(Exception):
                self._target.write(full)
        return len(text)

    def flush(self) -> None:
        if self._buf:
            full = self._buf
            self._buf = ""
            plain = re.sub(r"\x1b\[[0-9;]*m", "", full)
            if not any(sn in plain for sn in self._suppressed):
                with contextlib.suppress(Exception):
                    self._target.write(full)
        with contextlib.suppress(Exception):
            self._target.flush()


@contextlib.contextmanager
def _suppress_paddle_init_noise():
    out = _FilterLineWriter(sys.stdout, _SUPPRESSED_PADDLE_LOG_SNIPPETS)
    err = _FilterLineWriter(sys.stderr, _SUPPRESSED_PADDLE_LOG_SNIPPETS)
    with _suppress_native_stderr(), contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        yield
    out.flush()
    err.flush()


@contextlib.contextmanager
def _suppress_native_stderr():
    """
    Suppress native stderr writes (e.g. subprocesses spawned by Paddle init)
    that bypass Python-level redirect_stderr filters.
    """
    def _resolve_fileno(stream: Any) -> Optional[int]:
        visited = set()
        cur = stream
        while cur is not None and id(cur) not in visited:
            visited.add(id(cur))
            with contextlib.suppress(Exception):
                fd = cur.fileno()
                if isinstance(fd, int) and fd >= 0:
                    return int(fd)
            nxt = None
            for attr in ("_target", "target", "stream", "_stream", "wrapped", "_wrapped", "buffer"):
                if hasattr(cur, attr):
                    nxt = getattr(cur, attr)
                    if nxt is not None:
                        break
            cur = nxt
        return None

    stderr_fd = _resolve_fileno(sys.stderr)
    if stderr_fd is None:
        yield
        return
    dup_fd = None
    null_stream = None
    try:
        dup_fd = os.dup(stderr_fd)
        null_stream = open(os.devnull, "w", encoding="utf-8")
        os.dup2(null_stream.fileno(), stderr_fd)
        yield
    finally:
        if dup_fd is not None:
            with contextlib.suppress(Exception):
                os.dup2(dup_fd, stderr_fd)
            with contextlib.suppress(Exception):
                os.close(dup_fd)
        if null_stream is not None:
            with contextlib.suppress(Exception):
                null_stream.close()


def _set_hover_reader_cache(reader: Any) -> None:
    global _hover_reader_cache
    _hover_reader_cache = reader
    try:
        from scripts.click.hover import hover_bot as hb  # type: ignore

        setattr(hb, "_CACHED_READER", reader)
    except Exception:
        pass


def _get_shared_ocr_reader() -> Any:
    # Prefer region_grow OCR as the single shared Paddle reader.
    rg = _get_region_grow_module()
    if rg is not None and hasattr(rg, "get_ocr"):
        with _suppress_paddle_init_noise():
            return rg.get_ocr()  # type: ignore[attr-defined]
    raise RuntimeError("Shared OCR reader unavailable from region_grow.get_ocr()")


def preload_hover_reader():
    global _hover_reader_cache
    if _hover_reader_cache is not None:
        return
    try:
        reader = None
        with contextlib.suppress(Exception):
            reader = _get_shared_ocr_reader()
        if reader is not None:
            _set_hover_reader_cache(reader)
            log("[INFO] Preloaded shared OCR reader (region_grow -> hover).")
            return
        with _suppress_paddle_init_noise():
            from scripts.click.hover import hover_bot as hb  # type: ignore
            _set_hover_reader_cache(hb.create_paddleocr_reader(lang=hb.OCR_LANG))
        log("[INFO] Preloaded hover_bot OCR reader.")
    except Exception as exc:
        log(f"[WARN] Could not preload hover_bot reader: {exc}")


def _get_region_grow_module():
    """
    Import scripts.region_grow.region_grow once per process with the same fast settings
    that we used for the old subprocess-based call.
    """
    global _region_grow_module
    if _region_grow_module is not None:
        return _region_grow_module

    # Ustaw domyślne flagi środowiskowe tak jak dla wywołania CLI.
    os.environ.setdefault("RG_FAST", "1")
    os.environ.setdefault("RAPID_OCR_MAX_SIDE", "1920")
    os.environ.setdefault("RAPID_OCR_AUTOCROP", "0")
    os.environ.setdefault("RAPID_AUTOCROP_KEEP_RATIO", "0.9")
    os.environ.setdefault("RAPID_OCR_AUTOCROP_DELTA", "8")
    os.environ.setdefault("RAPID_OCR_AUTOCROP_PAD", "8")
    # GPU floodfill/cupy required.
    os.environ.setdefault("REGION_GROW_USE_GPU", "1")
    os.environ.setdefault("REGION_GROW_REQUIRE_GPU", "0")

    try:
        with _suppress_paddle_init_noise():
            from scripts.region_grow.region_grow import region_grow as rg  # type: ignore
    except Exception as exc:
        log(f"[WARN] Inline region_grow import failed, falling back to subprocess: {exc}")
        _region_grow_module = None
        return None

    _region_grow_module = rg
    if ADVANCED_DEBUG_MODE:
        try:
            setattr(rg, "VERBOSE", True)
        except Exception:
            pass
        try:
            setattr(rg, "DEBUG_OCR", True)
        except Exception:
            pass
        try:
            setattr(rg, "ENABLE_TIMINGS", True)
        except Exception:
            pass
        debug("Advanced debug applied to region_grow module (VERBOSE, DEBUG_OCR, ENABLE_TIMINGS).")
    return rg


def _get_rating_module():
    """
    Import scripts.region_grow.numpy_rate.rating raz na proces, tak aby rating
    by‘' wykonywany inline (bez dodatkowego procesu Pythona).
    """
    global _rating_module
    if _rating_module is not None:
        return _rating_module
    try:
        from scripts.region_grow.numpy_rate import rating as rt  # type: ignore
    except Exception as exc:
        log(f"[WARN] Inline rating import failed, falling back to subprocess: {exc}")
        _rating_module = None
        return None
    _rating_module = rt
    return rt


def warm_ocr_once():
    """
    Preload all OCR models (hover + region_grow) and keep them in VRAM
    for subsequent iterations. Idempotent.
    """
    global _ocr_warmed
    if _ocr_warmed:
        return
    t_ocr_total = time.perf_counter()

    # Single shared OCR warmup used by both region_grow and hover.
    try:
        t_shared_ocr = time.perf_counter()
        reader = _get_shared_ocr_reader()
        _set_hover_reader_cache(reader)
        log(f"[TIMER] shared_ocr_warm {time.perf_counter() - t_shared_ocr:.3f}s")
        with contextlib.suppress(Exception):
            if hasattr(reader, "warmup_stage1"):
                t_stage1_warm = time.perf_counter()
                sample_img = None
                sample_path = RAW_CURRENT_DIR / "screenshot.png"
                if sample_path.exists():
                    with contextlib.suppress(Exception):
                        import numpy as _np  # type: ignore

                        with Image.open(sample_path).convert("RGB") as _im:
                            sample_img = _np.ascontiguousarray(_np.array(_im))
                reader.warmup_stage1(sample_img)  # type: ignore[attr-defined]
                log(f"[TIMER] shared_ocr_stage1_warmup {time.perf_counter() - t_stage1_warm:.3f}s")
        log("[INFO] Preloaded shared OCR (region_grow + hover).")
    except Exception as exc:
        log(f"[WARN] Could not preload shared OCR: {exc}")
        # Fallback: keep legacy hover preload if shared path is unavailable.
        with contextlib.suppress(Exception):
            t_hover_ocr = time.perf_counter()
            preload_hover_reader()
            log(f"[TIMER] hover_ocr_warm {time.perf_counter() - t_hover_ocr:.3f}s")

    log(f"[TIMER] ocr_warm_total {time.perf_counter() - t_ocr_total:.3f}s")
    _ocr_warmed = True


def _current_interpreter_has_gpu_ocr() -> bool:
    try:
        import paddle  # type: ignore

        return bool(paddle is not None and paddle.is_compiled_with_cuda())
    except Exception:
        return False


def _wait_for_quiz_page_lock(url_prefix: str, timeout_s: float = 10.0) -> bool:
    def _controls_ready(controls_payload: dict) -> bool:
        if not isinstance(controls_payload, dict):
            return False
        page = controls_payload.get("page") if isinstance(controls_payload.get("page"), dict) else {}
        controls = controls_payload.get("controls") if isinstance(controls_payload.get("controls"), list) else []
        qblocks = controls_payload.get("question_blocks") if isinstance(controls_payload.get("question_blocks"), list) else []
        meta = controls_payload.get("meta") if isinstance(controls_payload.get("meta"), dict) else {}
        qid = str(meta.get("qid") or "").strip()
        controls_url = str((page or {}).get("url") or "").strip()
        action_kinds = {
            str((item or {}).get("kind") or "").strip().lower()
            for item in controls
            if isinstance(item, dict)
        }
        has_question = bool(qblocks or qid)
        has_quiz_inputs = bool(action_kinds & {"radio", "checkbox", "select", "option", "textbox", "button"})
        has_quiz_url = "/t/" in controls_url
        return bool((has_question and has_quiz_inputs) or (has_quiz_url and has_quiz_inputs))

    prefix = str(url_prefix or "").strip()
    if not prefix:
        return True
    deadline = time.time() + max(0.5, float(timeout_s))
    last_url = ""
    while time.time() < deadline:
        try:
            if CURRENT_PAGE_PATH.exists():
                payload = json.loads(CURRENT_PAGE_PATH.read_text(encoding="utf-8", errors="replace"))
                current_url = str(payload.get("url") or "").strip()
                if current_url:
                    last_url = current_url
                if current_url.startswith(prefix):
                    log(f"[INFO] Recorder page lock ready: {current_url}")
                    return True
        except Exception:
            pass
        try:
            if CURRENT_CONTROLS_PATH.exists():
                age_s = max(0.0, time.time() - CURRENT_CONTROLS_PATH.stat().st_mtime)
                controls_payload = json.loads(CURRENT_CONTROLS_PATH.read_text(encoding="utf-8", errors="replace"))
                page = controls_payload.get("page") if isinstance(controls_payload, dict) else {}
                controls = controls_payload.get("controls") if isinstance(controls_payload, dict) else []
                qblocks = controls_payload.get("question_blocks") if isinstance(controls_payload, dict) else []
                qid = str(((controls_payload.get("meta") if isinstance(controls_payload, dict) else {}) or {}).get("qid") or "").strip()
                controls_url = str((page or {}).get("url") or "").strip()
                if controls_url:
                    last_url = controls_url
                if controls_url.startswith(prefix) and (controls or qblocks):
                    log(
                        f"[INFO] Recorder quiz controls ready: url={controls_url} "
                        f"controls={len(controls) if isinstance(controls, list) else 0}"
                    )
                    return True
                if _controls_ready(controls_payload):
                    log(
                        "[INFO] Recorder quiz controls ready by semantic snapshot: "
                        f"url={controls_url or '-'} controls={len(controls) if isinstance(controls, list) else 0} "
                        f"qblocks={len(qblocks) if isinstance(qblocks, list) else 0} qid={qid or '-'}"
                    )
                    return True
                if age_s <= 2.0 and (controls or qblocks or qid):
                    log(
                        "[INFO] Recorder quiz controls ready without page url: "
                        f"controls={len(controls) if isinstance(controls, list) else 0} "
                        f"qblocks={len(qblocks) if isinstance(qblocks, list) else 0} qid={qid or '-'}"
                    )
                    return True
        except Exception:
            pass
        try:
            if CURRENT_QUESTION_PATH.exists():
                q_payload = json.loads(CURRENT_QUESTION_PATH.read_text(encoding="utf-8", errors="replace"))
                q_url = str((q_payload.get("url") if isinstance(q_payload, dict) else "") or "").strip()
                main_question = (q_payload.get("main_question") if isinstance(q_payload, dict) else None) or {}
                q_text = str((main_question.get("text") if isinstance(main_question, dict) else "") or "").strip()
                has_projection = bool(q_text or q_url.startswith(prefix))
                if q_url:
                    last_url = q_url
                if has_projection:
                    log(f"[INFO] Recorder quiz question projection ready: url={q_url or '-'} text_len={len(q_text)}")
                    return True
        except Exception:
            pass
        time.sleep(0.25)
    if last_url:
        log(f"[WARN] Recorder page lock timeout after {timeout_s:.1f}s (last_url={last_url})")
    else:
        log(f"[WARN] Recorder page lock timeout after {timeout_s:.1f}s (current_page.json not ready)")
    return False


def _minimize_console_window() -> bool:
    if os.name != "nt":
        return False
    try:
        import ctypes

        hwnd = ctypes.windll.kernel32.GetConsoleWindow()  # type: ignore[attr-defined]
        if not hwnd:
            return False
        SW_MINIMIZE = 6
        return bool(ctypes.windll.user32.ShowWindow(hwnd, SW_MINIMIZE))  # type: ignore[attr-defined]
    except Exception:
        return False

def update_overlay_status(message: str):
    if not message:
        return
    text = str(message)
    log(f"[INFO] {text}")
    overlay = globals().get("_status_overlay")
    if overlay is not None and hasattr(overlay, "update"):
        with contextlib.suppress(Exception):
            overlay.update(text)
def cancel_hover_fallback_timer():
    global _hover_fallback_timer
    if _hover_fallback_timer is not None:
        _hover_fallback_timer.cancel()
        _hover_fallback_timer = None


def start_hover_fallback_timer():
    global _hover_fallback_allowed
    if HOVER_FALLBACK_SECONDS <= 0:
        return
    if not _hover_fallback_allowed:
        return
    cancel_hover_fallback_timer()

    def _timeout():
        msg = f"Hover fallback! no response for {HOVER_FALLBACK_SECONDS:.0f}s. Stopping."
        log(f"[ERROR] {msg}")
        update_overlay_status(msg)
        os._exit(3)

    timer = threading.Timer(HOVER_FALLBACK_SECONDS, _timeout)
    timer.daemon = True
    timer.start()
    globals()["_hover_fallback_timer"] = timer
    update_overlay_status(f"Hover path sent. Awaiting response ({HOVER_FALLBACK_SECONDS:.0f}s timeout).")
    _hover_fallback_allowed = False


def log(message: str) -> None:
    msg = str(message)
    if LIGHT_INFO_DEBUG:
        # W trybie light przepuszczamy wyłącznie najważniejsze potwierdzenia
        # warmingu OCR i bootstrapu region_grow.
        if "[QUIZ_TYPE]" in msg:
            pass
        elif not ("[INFO]" in msg and any(token in msg for token in _LIGHT_INFO_ALLOWLIST)):
            return
    if ("[TIMER]" in msg) and (not ENABLE_TIMERS):
        return
    ts = datetime.now().strftime("%H:%M:%S")
    line = f"[main {ts}] {msg}"
    print(colorize_log_message(line), flush=True)


def debug(message: str) -> None:
    if DEBUG_MODE:
        log(f"[DEBUG] {message}")


BRAIN_AGENT = PipelineBrainAgent(
    question_path=CURRENT_QUESTION_PATH,
    state_path=BRAIN_STATE_FILE,
    logger=log,
    controls_path=CURRENT_CONTROLS_PATH,
    page_path=CURRENT_PAGE_PATH,
    quiz_answer_cache=QUIZ_ANSWER_CACHE_DEFAULT,
    current_run_dir=CURRENT_RUN_DIR,
)


_RECORDER_PYTHON_CACHE: Optional[Path] = None


def _python_has_module(python_path: Path, module_name: str) -> bool:
    try:
        result = subprocess.run(
            [
                str(python_path),
                "-c",
                (
                    "import importlib.util as u, sys; "
                    f"sys.exit(0 if u.find_spec({module_name!r}) else 1)"
                ),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10.0,
            check=False,
        )
        return int(result.returncode) == 0
    except Exception:
        return False


def _resolve_ai_recorder_python() -> Path:
    global _RECORDER_PYTHON_CACHE
    if _RECORDER_PYTHON_CACHE is not None and _RECORDER_PYTHON_CACHE.exists():
        return _RECORDER_PYTHON_CACHE

    candidates: List[Path] = []

    def _push(raw: Optional[str]) -> None:
        value = str(raw or "").strip()
        if not value:
            return
        path = Path(value)
        if not path.exists():
            return
        if any(str(existing).lower() == str(path).lower() for existing in candidates):
            return
        candidates.append(path)

    _push(os.environ.get("FULLBOT_RECORDER_PYTHON"))
    _push(os.environ.get("FULLBOT_RUNTIME_PYTHON"))
    _push(str(ROOT.parent / ".venv312" / "Scripts" / "python.exe"))
    _push(sys.executable)

    for candidate in candidates:
        if _python_has_module(candidate, "playwright"):
            _RECORDER_PYTHON_CACHE = candidate
            return candidate

    fallback = Path(sys.executable)
    _RECORDER_PYTHON_CACHE = fallback
    return fallback


def _debug_hover_output_current() -> None:
    """
    Lightweight debug helper for hover_output_current state.
    Używane tylko tymczasowo do diagnozy, czy pliki się nadpisują.
    """
    try:
        json_path = HOVER_OUTPUT_CURRENT_DIR / "hover_output.json"
        png_path = HOVER_OUTPUT_CURRENT_DIR / "hover_output.png"
        json_info = (
            f"exists={json_path.exists()} "
            f"size={(json_path.stat().st_size if json_path.exists() else 0)}"
        )
        png_info = (
            f"exists={png_path.exists()} "
            f"size={(png_path.stat().st_size if png_path.exists() else 0)}"
        )
        debug(f"hover_output_current json {json_info} | png {png_info}")
    except Exception as exc:
        debug(f"hover_output_current debug failed: {exc}")


def _write_current_artifact(src: Path, dest_dir: Path, dest_name: Optional[str] = None) -> Optional[Path]:
    """
    Copy a file into a "current" directory, replacing previous content.
    Returns the destination path or None if the source is missing.
    """
    if src is None or not src.exists():
        return None
    dest_dir.mkdir(parents=True, exist_ok=True)
    target = dest_dir / (dest_name or src.name)
    if target.exists() and target.is_file():
        with contextlib.suppress(Exception):
            target.unlink()
    shutil.copy2(src, target)
    return target


def _archive_artifact(src: Path, dest_dir: Path, dest_name: Optional[str] = None) -> Optional[Path]:
    """
    Copy a file into an archive/run directory (non-destructive).
    """
    if src is None or not src.exists():
        return None
    dest_dir.mkdir(parents=True, exist_ok=True)
    target = dest_dir / (dest_name or src.name)
    shutil.copy2(src, target)
    return target


def _sync_current_dirs_into_current_run() -> int:
    """
    Mirror all files from directories with names ending in *_current into current_run.
    Keeps relative structure under data/screen to avoid filename collisions.
    """
    copied = 0
    try:
        root = DATA_SCREEN_DIR.resolve()
    except Exception:
        root = DATA_SCREEN_DIR
    dest_root = CURRENT_RUN_DIR
    with contextlib.suppress(Exception):
        dest_root.mkdir(parents=True, exist_ok=True)
    for d in DATA_SCREEN_DIR.rglob("*"):
        try:
            if not d.is_dir():
                continue
            if not d.name.lower().endswith("current"):
                continue
            d_resolved = d.resolve()
            dest_resolved = dest_root.resolve()
            if d_resolved == dest_resolved:
                continue
            if str(d_resolved).lower().startswith(str(dest_resolved).lower() + "\\"):
                continue
            rel = d_resolved.relative_to(root)
            dest_dir = dest_root / rel
            with contextlib.suppress(Exception):
                dest_dir.mkdir(parents=True, exist_ok=True)
            for src in d.rglob("*"):
                if not src.is_file():
                    continue
                rel_file = src.relative_to(d)
                target = dest_dir / rel_file
                with contextlib.suppress(Exception):
                    target.parent.mkdir(parents=True, exist_ok=True)
                with contextlib.suppress(Exception):
                    shutil.copy2(src, target)
                    copied += 1
        except Exception:
            continue
    return copied


def capture_fullscreen(target: Path) -> Path:
    def _get_mss():
        return _mss_singleton

    def _set_mss(v: object):
        global _mss_singleton
        _mss_singleton = v

    overlay = globals().get("_status_overlay")
    if overlay is not None and hasattr(overlay, "hide"):
        with contextlib.suppress(Exception):
            overlay.hide()
        time.sleep(max(0.0, float(OVERLAY_HIDE_BEFORE_SCREENSHOT_S)))
    try:
        return _capture_fullscreen_mod(
            target,
            mss_singleton_get=_get_mss,
            mss_singleton_set=_set_mss,
            screen_top_crop_px=SCREEN_TOP_CROP_PX,
            log=log,
        )
    finally:
        if overlay is not None and hasattr(overlay, "show"):
            time.sleep(max(0.0, float(OVERLAY_SHOW_AFTER_SCREENSHOT_S)))
            with contextlib.suppress(Exception):
                overlay.show()


def _downscale_for_region(src: Path) -> Path:
    if REGION_RESIZE_MAX_SIDE <= 0:
        return src
    try:
        with Image.open(src) as im:
            w, h = im.size
            side = max(w, h)
            if side <= REGION_RESIZE_MAX_SIDE:
                return src
            scale = REGION_RESIZE_MAX_SIDE / float(side)
            nw, nh = int(w * scale), int(h * scale)
            resized = im.resize((nw, nh), Image.LANCZOS)
            # Keep raw screenshot directory clean: store transient region image in current_run.
            CURRENT_RUN_DIR.mkdir(parents=True, exist_ok=True)
            tmp_path = CURRENT_RUN_DIR / f"{src.stem}_rg_small{src.suffix}"
            resized.save(tmp_path)
            debug(f"region resize: {w}x{h} -> {nw}x{nh} at {tmp_path}")
            return tmp_path
    except Exception as exc:
        debug(f"region resize failed: {exc}")
        return src


def prepare_hover_image(full_image: Path) -> Optional[Path]:
    return _prepare_hover_image_mod(
        full_image,
        raw_current_dir=RAW_CURRENT_DIR,
        hover_top_crop=HOVER_TOP_CROP,
        hover_input_dir=HOVER_INPUT_DIR,
        hover_input_current_dir=HOVER_INPUT_CURRENT_DIR,
        write_current_artifact=_write_current_artifact,
        debug=debug,
        log=log,
    )


def run_region_grow(image_path: Path) -> Optional[Path]:
    return _run_region_grow_mod(
        image_path,
        get_region_grow_module=_get_region_grow_module,
        data_screen_dir=DATA_SCREEN_DIR,
        region_grow_current_dir=REGION_GROW_CURRENT_DIR,
        region_grow_annot_dir=REGION_GROW_ANNOT_DIR,
        region_grow_json_dir=REGION_GROW_JSON_DIR,
        screen_boxes_dir=SCREEN_BOXES_DIR,
        region_grow_script=REGION_GROW_SCRIPT,
        root=ROOT,
        region_grow_timeout=REGION_GROW_TIMEOUT,
        debug_mode=DEBUG_MODE,
        debug=debug,
        log=log,
        write_current_artifact=_write_current_artifact,
        subprocess_kw=SUBPROCESS_KW,
        sys_executable=sys.executable,
    )


def bootstrap_region_grow_worker() -> bool:
    return _bootstrap_region_grow_worker_mod(
        root=ROOT,
        region_grow_script=REGION_GROW_SCRIPT,
        subprocess_kw=SUBPROCESS_KW,
        sys_executable=sys.executable,
        region_grow_timeout=REGION_GROW_TIMEOUT,
        debug_mode=DEBUG_MODE,
        debug=debug,
        log=log,
    )


def run_arrow_post(json_path: Path) -> None:
    _run_arrow_post_mod(json_path, log=log)


def run_region_annotation(json_path: Path, image_path: Path) -> Optional[Path]:
    return _run_region_annotation_mod(
        json_path,
        image_path=image_path,
        get_region_grow_module=_get_region_grow_module,
        region_grow_annot_dir=REGION_GROW_ANNOT_DIR,
        region_grow_annot_current_dir=REGION_GROW_ANNOT_CURRENT_DIR,
        write_current_artifact=_write_current_artifact,
        log=log,
    )


def schedule_deferred_debug_render(json_path: Path, image_path: Path, loop_idx: int) -> bool:
    worker = globals().get("_deferred_debug_worker")
    if worker is None:
        return False
    schedule = getattr(worker, "schedule", None)
    if not callable(schedule):
        return False
    try:
        return bool(schedule(json_path, image_path, int(loop_idx)))
    except Exception as exc:
        log(f"[WARN] Deferred debug schedule failed: {exc}")
        return False


def run_rating(json_path: Path) -> bool:
    return _run_rating_mod(
        json_path,
        get_rating_module=_get_rating_module,
        rating_script=RATING_SCRIPT,
        root=ROOT,
        subprocess_kw=SUBPROCESS_KW,
        sys_executable=sys.executable,
        log=log,
    )


def _legacy_build_hover_from_region_results(json_path: Path) -> Optional[Path]:
    return build_hover_from_region_results(json_path)


def build_hover_from_region_results(json_path: Path) -> Optional[Path]:
    return _hover_runtime.build_hover_from_region_results(
        json_path,
        screenshot_dir=SCREENSHOT_DIR,
        raw_current_dir=RAW_CURRENT_DIR,
        hover_output_dir=HOVER_OUTPUT_DIR,
        hover_output_current_dir=HOVER_OUTPUT_CURRENT_DIR,
        write_current_artifact=_write_current_artifact,
        debug_hover_output_current=_debug_hover_output_current,
        debug=debug,
        log=log,
    )


def run_hover_bot(
    hover_image: Path,
    base_name: str,
    start_time: Optional[float] = None,
) -> Optional[Tuple[subprocess.Popen, Path, Path]]:
    def _cache_get():
        return _hover_reader_cache

    def _cache_set(v: Any):
        global _hover_reader_cache
        _hover_reader_cache = v

    return _hover_runtime.run_hover_bot(
        hover_image,
        base_name,
        start_time=start_time,
        hover_output_dir=HOVER_OUTPUT_DIR,
        hover_output_current_dir=HOVER_OUTPUT_CURRENT_DIR,
        screenshot_dir=SCREENSHOT_DIR,
        root=ROOT,
        subprocess_kw=SUBPROCESS_KW,
        hover_single_script=HOVER_SINGLE_SCRIPT,
        write_current_artifact=_write_current_artifact,
        debug_hover_output_current=_debug_hover_output_current,
        dispatch_hover_to_control_agent=dispatch_hover_to_control_agent,
        update_overlay_status=update_overlay_status,
        debug=debug,
        log=log,
        hover_reader_cache_get=_cache_get,
        hover_reader_cache_set=_cache_set,
    )


def _send_click_from_bbox(
    bbox: List[float],
    image_path: Optional[Path],
    context_label: str,
) -> bool:
    return _send_click_from_bbox_mod(
        bbox,
        image_path,
        context_label,
        send_control_agent=_send_control_agent,
        control_agent_port=CONTROL_AGENT_PORT,
        log=log,
        update_overlay_status=update_overlay_status,
        screen_click_offset_x=SCREEN_CLICK_OFFSET_X,
        screen_click_offset_y=SCREEN_CLICK_OFFSET_Y,
    )


def scroll_on_box(
    bbox: List[float],
    image_path: Optional[Path],
    context_label: str,
    *,
    total_notches: int = 8,
    direction: str = "down",
) -> bool:
    return _scroll_on_box_mod(
        bbox,
        image_path,
        context_label,
        send_control_agent=_send_control_agent,
        control_agent_port=CONTROL_AGENT_PORT,
        log=log,
        total_notches=total_notches,
        direction=direction,
        screen_click_offset_x=SCREEN_CLICK_OFFSET_X,
        screen_click_offset_y=SCREEN_CLICK_OFFSET_Y,
    )


def send_key(combo: str) -> bool:
    return _send_key_mod(combo, CONTROL_AGENT_PORT, log=log)


def send_key_repeat(key: str, count: int) -> bool:
    return _send_key_repeat_mod(key, count, CONTROL_AGENT_PORT, log=log)


def send_type(text: str) -> bool:
    return _send_type_mod(text, CONTROL_AGENT_PORT, log=log)


def send_wait(ms: int) -> bool:
    return _send_wait_mod(ms, log=log)


def _hover_rect(box: List[List[float]]) -> Tuple[int, int, int, int]:
    return _hover_runtime.hover_rect(box)


def _inside_any(x: float, y: float, rects: List[Tuple[int, int, int, int]]) -> bool:
    return _hover_runtime.inside_any(x, y, rects)


def _group_hover_lines(seqs: List[Dict[str, Any]]) -> List[List[int]]:
    return _hover_runtime.group_hover_lines(seqs)


def _build_hover_path(
    seqs: List[Dict[str, Any]],
    offset_x: int,
    offset_y: int,
) -> Optional[Dict[str, Any]]:
    return _hover_runtime.build_hover_path(
        seqs,
        offset_x,
        offset_y,
        brain_agent=BRAIN_AGENT,
        hover_speed_defaults=HOVER_SPEED_DEFAULTS,
    )

def _send_udp_payload(payload: Dict[str, Any], port: int) -> bool:
    return _send_udp_payload_mod(payload, port, log=log)


def _control_agent_running() -> bool:
    target = "control_agent.py"
    try:
        import psutil  # type: ignore
    except Exception:
        return False
    try:
        proc_iter = psutil.process_iter(["cmdline"])
    except Exception:
        return False
    for proc in proc_iter:
        try:
            cmdline = " ".join(proc.info.get("cmdline") or [])
        except (PermissionError, psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess):
            continue
        except Exception:
            continue
        if target in cmdline:
            return True
    return False


def _save_hover_path_visual(points: List[Dict[str, int]], points_json: Path) -> None:
    _hover_runtime.save_hover_path_visual(
        points,
        points_json,
        screenshot_dir=SCREENSHOT_DIR,
        hover_input_current_dir=HOVER_INPUT_CURRENT_DIR,
        raw_current_dir=RAW_CURRENT_DIR,
        hover_path_dir=HOVER_PATH_DIR,
        hover_path_current_dir=HOVER_PATH_CURRENT_DIR,
        debug=debug,
        log=log,
    )


def _save_hover_overlay_from_json(points_json: Path) -> None:
    _hover_runtime.save_hover_overlay_from_json(
        points_json,
        region_grow_annot_current_dir=REGION_GROW_ANNOT_CURRENT_DIR,
        raw_current_dir=RAW_CURRENT_DIR,
        screenshot_dir=SCREENSHOT_DIR,
        hover_output_dir=HOVER_OUTPUT_DIR,
        hover_output_current_dir=HOVER_OUTPUT_CURRENT_DIR,
        write_current_artifact=_write_current_artifact,
        debug_hover_output_current=_debug_hover_output_current,
        debug=debug,
    )


def ensure_control_agent(port: int) -> Optional[subprocess.Popen]:
    return _ensure_control_agent_mod(
        control_agent_running=_control_agent_running,
        control_agent_script=CONTROL_AGENT_SCRIPT,
        control_agent_port=int(port),
        root=ROOT,
        subprocess_kw=SUBPROCESS_KW,
        log=log,
    )


def _send_control_agent(payload: Dict[str, Any], port: int) -> bool:
    return _send_control_agent_mod(payload, port, log=log)


def dispatch_hover_to_control_agent(points_json: Path) -> None:
    _dispatch_hover_to_control_agent_mod(
        points_json,
        hover_input_current_dir=HOVER_INPUT_CURRENT_DIR,
        raw_current_dir=RAW_CURRENT_DIR,
        hold_left_button=bool(HOLD_LEFT_BUTTON),
        control_agent_port=CONTROL_AGENT_PORT,
        build_hover_path=_build_hover_path,
        save_hover_path_visual=_save_hover_path_visual,
        save_hover_overlay_from_json=_save_hover_overlay_from_json,
        send_control_agent=_send_control_agent,
        start_hover_fallback_timer=start_hover_fallback_timer,
        screen_click_offset_x=SCREEN_CLICK_OFFSET_X,
        screen_click_offset_y=SCREEN_CLICK_OFFSET_Y,
        log=log,
    )



def finalize_hover_bot(task: Tuple[subprocess.Popen, Path, Path]) -> None:
    _hover_runtime.finalize_hover_bot(
        task,
        hover_output_current_dir=HOVER_OUTPUT_CURRENT_DIR,
        write_current_artifact=_write_current_artifact,
        dispatch_hover_to_control_agent=dispatch_hover_to_control_agent,
        debug=debug,
        log=log,
        debug_mode=DEBUG_MODE,
    )


def send_random_click(summary_path: Path, image_path: Path) -> None:
    _send_random_click_mod(
        summary_path,
        image_path,
        send_control_agent=_send_control_agent,
        control_agent_port=CONTROL_AGENT_PORT,
        cancel_hover_fallback_timer=cancel_hover_fallback_timer,
        log=log,
        update_overlay_status=update_overlay_status,
        screen_click_offset_x=SCREEN_CLICK_OFFSET_X,
        screen_click_offset_y=SCREEN_CLICK_OFFSET_Y,
    )


def _latest_file(directory: Path, suffixes: Tuple[str, ...]) -> Optional[Path]:
    return _latest_file_mod(directory, suffixes)


def run_region_grow_latest() -> Optional[Path]:
    latest = _latest_file(SCREENSHOT_DIR, _IMAGE_EXTS)
    if latest is None:
        log("[WARN] No screenshots available for manual region_grow.")
        update_overlay_status("No screenshots for region_grow.")
        return None
    update_overlay_status(f"Manual region_grow on {latest.name}")
    json_path = run_region_grow(latest)
    if json_path:
        run_arrow_post(json_path)
        rendered_async = False
        try:
            rendered_async = schedule_deferred_debug_render(json_path, latest, 0)
        except Exception as exc:
            log(f"[WARN] Manual deferred debug schedule failed: {exc}")
            rendered_async = False
        if not rendered_async:
            try:
                run_region_annotation(json_path, latest)
            except Exception as exc:
                log(f"[WARN] Manual region_grow annotation failed: {exc}")
        update_overlay_status(f"region_grow completed ({json_path.name})")
    else:
        update_overlay_status("region_grow failed.")
    return json_path


def run_rating_latest() -> bool:
    latest = _latest_file(SCREEN_BOXES_DIR, _JSON_EXTS)
    if latest is None:
        log("[WARN] No JSON files in screen_boxes for manual rating.")
        update_overlay_status("No JSON for rating.")
        return False
    update_overlay_status(f"Manual rating for {latest.name}")
    run_arrow_post(latest)
    ok = run_rating(latest)
    update_overlay_status("rating completed." if ok else "rating failed.")
    return ok


def _find_screenshot_for_summary(summary_path: Path) -> Optional[Path]:
    return _find_screenshot_for_summary_mod(
        summary_path,
        screenshot_dir=SCREENSHOT_DIR,
        image_exts=_IMAGE_EXTS,
    )


def send_best_click(summary_path: Path, image_path: Optional[Path]) -> None:
    _send_best_click_mod(
        summary_path,
        image_path,
        send_control_agent=_send_control_agent,
        control_agent_port=CONTROL_AGENT_PORT,
        log=log,
        update_overlay_status=update_overlay_status,
        screen_click_offset_x=SCREEN_CLICK_OFFSET_X,
        screen_click_offset_y=SCREEN_CLICK_OFFSET_Y,
    )


def trigger_best_click_from_summary() -> None:
    summary = _latest_file(RATE_SUMMARY_DIR, _JSON_EXTS)
    if summary is None:
        log("[WARN] No summary JSONs available for control agent.")
        update_overlay_status("No summary for control agent.")
        return
    screenshot = _find_screenshot_for_summary(summary)
    if screenshot is None:
        log("[WARN] Matching screenshot not found for summary, using defaults.")
    send_best_click(summary, screenshot)


def abort_current_iteration() -> None:
    globals()["_abort_iteration_requested"] = True
    cancel_hover_fallback_timer()
    sent = _send_control_agent({"cmd": "abort"}, CONTROL_AGENT_PORT)
    if sent:
        log("[INFO] Abort sent to control_agent (hover stop requested).")
    else:
        log("[WARN] Abort command could not be sent to control_agent.")
    update_overlay_status("Abort requested for current iteration.")


def _handle_manual_command(
    command: str,
    args: argparse.Namespace,
    recorder_proc: Optional[subprocess.Popen],
) -> Optional[subprocess.Popen]:
    return _handle_manual_command_mod(
        command,
        args=args,
        recorder_proc=recorder_proc,
        run_region_grow_latest=run_region_grow_latest,
        run_rating_latest=run_rating_latest,
        start_ai_recorder=start_ai_recorder,
        trigger_best_click_from_summary=trigger_best_click_from_summary,
        abort_current_iteration=abort_current_iteration,
        log=log,
        update_overlay_status=update_overlay_status,
    )


def _drain_manual_commands(
    cmd_queue: "queue.Queue[str]",
    args: argparse.Namespace,
    recorder_proc: Optional[subprocess.Popen],
) -> Optional[subprocess.Popen]:
    return _drain_manual_commands_mod(
        cmd_queue,
        args=args,
        recorder_proc=recorder_proc,
        run_region_grow_latest=run_region_grow_latest,
        run_rating_latest=run_rating_latest,
        start_ai_recorder=start_ai_recorder,
        trigger_best_click_from_summary=trigger_best_click_from_summary,
        abort_current_iteration=abort_current_iteration,
        log=log,
        update_overlay_status=update_overlay_status,
    )


def start_ai_recorder(extra_args: Optional[Iterable[str]] = None) -> Optional[subprocess.Popen]:
    recorder_python = _resolve_ai_recorder_python()
    if str(recorder_python).lower() != str(sys.executable).lower():
        log(f"[INFO] ai_recorder interpreter override -> {recorder_python}")
    return _start_ai_recorder_mod(
        ai_recorder_script=AI_RECORDER_SCRIPT,
        root=ROOT,
        subprocess_kw=SUBPROCESS_KW,
        log=log,
        extra_args=extra_args,
        python_executable=str(recorder_python),
    )


def _find_chrome_exe() -> Optional[Path]:
    if os.name == "nt":
        candidates = [
            Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
            Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
            Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
            Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
        ]
    elif sys.platform == "darwin":
        candidates = [
            Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
            Path("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
        ]
    else:
        candidates = [
            Path("/usr/bin/google-chrome"),
            Path("/usr/bin/google-chrome-stable"),
            Path("/usr/bin/chromium"),
            Path("/usr/bin/chromium-browser"),
        ]
    for p in candidates:
        if p.exists():
            return p
    return None


def _normalize_recorder_args(extra_args: Optional[Iterable[str]]) -> List[str]:
    args = list(extra_args or [])
    if args and args[0] == "--":
        args = args[1:]
    return args


def _has_flag(args: List[str], flag: str) -> bool:
    return any(a == flag or str(a).startswith(flag + "=") for a in args)


def _probe_cdp_endpoint(endpoint: str, timeout_s: float = 0.6) -> bool:
    try:
        req = urllib.request.Request(endpoint.rstrip("/") + "/json/version")
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            return int(getattr(resp, "status", 0) or 0) == 200
    except Exception:
        return False


def _probe_http_alive(url: str, timeout_s: float = 0.6) -> bool:
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            status = int(getattr(resp, "status", 0) or 0)
            return 200 <= status < 500
    except Exception:
        return False


def _cdp_list_pages(endpoint: str) -> List[Dict[str, Any]]:
    base = str(endpoint or "").rstrip("/")
    if not base:
        return []
    try:
        req = urllib.request.Request(base + "/json/list")
        with urllib.request.urlopen(req, timeout=1.2) as resp:
            payload = json.loads(resp.read().decode("utf-8", errors="replace"))
    except Exception:
        return []
    out: List[Dict[str, Any]] = []
    if not isinstance(payload, list):
        return out
    for row in payload:
        if not isinstance(row, dict):
            continue
        if str(row.get("type") or "").strip().lower() != "page":
            continue
        out.append(row)
    return out


def _cdp_activate_page(endpoint: str, target_id: str) -> bool:
    base = str(endpoint or "").rstrip("/")
    tid = str(target_id or "").strip()
    if (not base) or (not tid):
        return False
    try:
        req = urllib.request.Request(base + f"/json/activate/{tid}")
        with urllib.request.urlopen(req, timeout=1.2) as resp:
            _ = resp.read()
        return True
    except Exception:
        return False


def _ensure_active_tab_via_cdp(url_prefix: str) -> bool:
    endpoint = f"http://127.0.0.1:{RECORDER_CDP_PORT}"
    prefix = str(url_prefix or "").strip()
    if not prefix:
        return False
    pages = _cdp_list_pages(endpoint)
    if not pages:
        log("[WARN] CDP active-tab lock skipped: no page targets.")
        return False
    best: Optional[Dict[str, Any]] = None
    best_score = -1
    for row in pages:
        url_now = str(row.get("url") or "").strip()
        if not url_now:
            continue
        if not url_now.startswith(prefix):
            continue
        score = len(url_now)
        if score > best_score:
            best = row
            best_score = score
    if best is None:
        log(f"[WARN] CDP active-tab lock: no tab matches prefix {prefix}")
        return False
    tid = str(best.get("id") or "").strip()
    url_now = str(best.get("url") or "").strip()
    title = str(best.get("title") or "").strip()
    if not tid:
        log(f"[WARN] CDP active-tab lock: matched page has no target id (url={url_now})")
        return False
    ok = _cdp_activate_page(endpoint, tid)
    if ok:
        log(f"[INFO] CDP active tab locked: {title[:80]} | {url_now}")
        return True
    log(f"[WARN] CDP active-tab activate failed for target {tid} ({url_now})")
    return False


def start_cdp_browser_for_recorder() -> Tuple[Optional[subprocess.Popen], bool]:
    enabled = str(os.environ.get("FULLBOT_START_CDP_BROWSER", "1") or "1").strip().lower() in {"1", "true", "yes", "on"}
    if not enabled:
        return None, False
    endpoint = f"http://127.0.0.1:{RECORDER_CDP_PORT}"
    if _probe_cdp_endpoint(endpoint):
        log(f"[INFO] CDP browser already running on {endpoint} (skip launch).")
        return None, True
    exe = _find_chrome_exe()
    if exe is None:
        log("[WARN] Chrome/Edge executable not found for recorder CDP launch.")
        return None, False
    RECORDER_PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    args = [
        str(exe),
        f"--user-data-dir={RECORDER_PROFILE_DIR}",
        f"--remote-debugging-port={RECORDER_CDP_PORT}",
        "--no-first-run",
        "--no-default-browser-check",
        "--start-maximized",
        "--lang=en-US",
    ]
    try:
        # Browser process should stay visible; do not inherit CREATE_NO_WINDOW flags.
        proc = subprocess.Popen(args, cwd=str(ROOT))
        log(f"[INFO] CDP browser launched (pid={proc.pid}, port={RECORDER_CDP_PORT})")
        return proc, True
    except Exception as exc:
        log(f"[WARN] Failed to launch CDP browser for recorder: {exc}")
        return None, False


def start_quiz_server() -> Optional[subprocess.Popen]:
    if _probe_http_alive(QUIZ_SERVER_URL, timeout_s=0.4):
        log(f"[INFO] quiz server already running at {QUIZ_SERVER_URL} (skip launch).")
        return None
    script = QUIZ_SERVER_SCRIPT
    if not script.exists():
        log(f"[WARN] Quiz server script not found: {script}")
        return None
    cmd = [sys.executable, str(script)]
    creationflags = 0
    if os.name == "nt":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        creationflags = CREATE_NO_WINDOW | DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    try:
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            creationflags=creationflags if os.name == "nt" else 0,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        log(f"[INFO] quiz server launched (pid={proc.pid}) at {QUIZ_SERVER_URL}")
        return proc
    except Exception as exc:
        log(f"[WARN] Failed to launch quiz server: {exc}")
        return None


def stop_process(proc: Optional[subprocess.Popen], timeout: float = 5.0) -> None:
    _stop_process_mod(proc, timeout=timeout, log=log)


def _pipeline_iteration_impl(
    loop_idx: int,
    screenshot_prefix: str = "screen",
    input_image: Optional[Path] = None,
    fast_skip: bool = False,
) -> None:
    _run_iteration_orchestrator(
        loop_idx=loop_idx,
        screenshot_prefix=screenshot_prefix,
        input_image=input_image,
        fast_skip=fast_skip,
        deps={
            "globals_fn": globals,
            "SCREENSHOT_DIR": SCREENSHOT_DIR,
            "RAW_CURRENT_DIR": RAW_CURRENT_DIR,
            "CURRENT_RUN_DIR": CURRENT_RUN_DIR,
            "capture_fullscreen": capture_fullscreen,
            "write_current_artifact": _write_current_artifact,
            "DEBUG_MODE": DEBUG_MODE,
            "debug": debug,
            "log": log,
            "update_overlay_status": update_overlay_status,
            "prepare_hover_image": prepare_hover_image,
            "run_hover_bot": run_hover_bot,
            "finalize_hover_bot": finalize_hover_bot,
            "downscale_for_region": _downscale_for_region,
            "run_region_grow": run_region_grow,
            "build_hover_from_region_results": build_hover_from_region_results,
            "dispatch_hover_to_control_agent": dispatch_hover_to_control_agent,
            "run_arrow_post": run_arrow_post,
            "run_region_annotation": run_region_annotation,
            "schedule_deferred_debug_render": schedule_deferred_debug_render,
            "run_rating": run_rating,
            "RATE_RESULTS_DIR": RATE_RESULTS_DIR,
            "RATE_RESULTS_DEBUG_DIR": RATE_RESULTS_DEBUG_DIR,
            "RATE_RESULTS_CURRENT_DIR": RATE_RESULTS_CURRENT_DIR,
            "RATE_RESULTS_DEBUG_CURRENT_DIR": RATE_RESULTS_DEBUG_CURRENT_DIR,
            "RATE_SUMMARY_DIR": RATE_SUMMARY_DIR,
            "RATE_SUMMARY_CURRENT_DIR": RATE_SUMMARY_CURRENT_DIR,
            "BRAIN_AGENT": BRAIN_AGENT,
            "send_click_from_bbox": _send_click_from_bbox,
            "scroll_on_box": scroll_on_box,
            "find_screenshot_for_summary": _find_screenshot_for_summary,
            "send_best_click": send_best_click,
            "send_random_click": send_random_click,
            "send_key": send_key,
            "send_key_repeat": send_key_repeat,
            "send_type": send_type,
            "send_wait": send_wait,
            "ensure_dom_fallback": ensure_dom_fallback,
            "sync_current_dirs_into_current_run": _sync_current_dirs_into_current_run,
            "cancel_hover_fallback_timer": cancel_hover_fallback_timer,
        },
    )


def pipeline_iteration(
    loop_idx: int,
    screenshot_prefix: str = "screen",
    input_image: Optional[Path] = None,
    fast_skip: bool = False,
) -> None:
    _pipeline_iteration_external(
        loop_idx=loop_idx,
        screenshot_prefix=screenshot_prefix,
        input_image=input_image,
        fast_skip=fast_skip,
    )


def parse_args() -> argparse.Namespace:
    return _parse_args_mod()


def start_hotkey_listener(
    event: threading.Event, command_queue: "queue.Queue[str]"
) -> Optional["keyboard.Listener"]:
    def _soft_exit() -> None:
        # Soft-exit: intentionally keep OCR/region_grow backend alive.
        with contextlib.suppress(Exception):
            log("[INFO] Soft exit: keeping region_grow daemon alive.")

    def _full_exit() -> None:
        # Full-exit: shutdown backend daemon before process exit.
        with contextlib.suppress(Exception):
            _stop_region_grow_daemon_mod(log=log)

    return _start_hotkey_listener_mod(
        event,
        command_queue,
        log=log,
        debug=debug,
        update_overlay_status=update_overlay_status,
        globals_fn=globals,
        is_debug_mode=lambda: bool(DEBUG_MODE),
        soft_exit_fn=_soft_exit,
        full_exit_fn=_full_exit,
    )


def _wait_for_p_in_console() -> None:
    _wait_for_p_in_console_mod()


def main() -> None:
    args = parse_args()
    _apply_debug_settings_from_args(args)
    with contextlib.suppress(Exception):
        ANSWERS_DIR.mkdir(parents=True, exist_ok=True)
    if str(getattr(args, "quiz_answer_cache", "") or "").strip():
        os.environ["FULLBOT_QUIZ_ANSWER_CACHE"] = str(Path(str(args.quiz_answer_cache)).expanduser())
    else:
        os.environ.setdefault("FULLBOT_QUIZ_ANSWER_CACHE", str(QUIZ_ANSWER_CACHE_DEFAULT))
    overlay_status = init_console_overlay(alpha=220)
    globals()["_status_overlay"] = overlay_status.get("status_overlay")
    turbo_mode = str(os.environ.get("FULLBOT_TURBO_MODE", "1") or "1").strip().lower() in {"1", "true", "yes", "on"}
    if turbo_mode:
        log(
            "[INFO] Turbo mode active (GPU-only): "
            f"RATING_MODE={os.environ.get('RATING_MODE', 'heavy')} "
            f"MAX_SIDE={os.environ.get('REGION_GROW_MAX_SIDE_TURBO', '1920')} "
            f"MAX_DET={os.environ.get('REGION_GROW_MAX_DETECTIONS_TURBO', '60')}"
        )
    log(f"[INFO] Screen top-crop active: {SCREEN_TOP_CROP_PX}px (tabs bar removed).")

    # Tryb bezpiecznego testu (bez przejmowania myszy).
    if args.safe_test:
        args.autostart_control_agent = False

    # Tryb specjalny: pierwszy agent (hover -> control) i nic więcej.
    # Używamy go do testów opóźnień od screena do pierwszego ruchu agenta.
    if getattr(args, "first_agent", False):
        args.auto = True
        args.loop_count = 1
        args.fast_skip = True  # pomijamy region_grow + rating
        args.disable_recorder = True
        args.autostart_control_agent = True

    # Tryb pomiaru całego pipeline'u bez hotkey'a.
    if args.notime:
        args.auto = True
        if args.loop_count is None:
            args.loop_count = 1
        if args.input_image:
            args.disable_recorder = True
        preload_hover_reader()
    globals()["HOLD_LEFT_BUTTON"] = bool(args.left)
    globals()["ADVANCED_DEBUG_MODE"] = bool(getattr(args, "advanced_debug", False))
    globals()["DEBUG_MODE"] = bool(args.debug or globals()["ADVANCED_DEBUG_MODE"])
    if globals()["ADVANCED_DEBUG_MODE"]:
        log(
            "[INFO] ADVANCED DEBUG enabled "
            "(region_grow + rating + rating_fast + control_agent + OCR + timers)"
        )
    if os.name == "nt":
        if bool(overlay_status.get("transparency_applied")):
            log("[INFO] Console overlay active (green + semi-transparent).")
        else:
            reason = str(overlay_status.get("transparency_reason") or "unknown")
            log(
                f"[WARN] Console overlay transparency not active "
                f"(reason={reason}, console_window_found={bool(overlay_status.get('console_window_found'))})."
            )
            if bool(overlay_status.get("pseudo_overlay_applied")):
                log("[INFO] Pseudo overlay active (VT green background fallback).")
            if bool(overlay_status.get("gui_overlay_applied")):
                log("[INFO] GUI status overlay active (ConPTY/VSCode fallback).")
            if (not bool(overlay_status.get("gui_overlay_applied"))) and overlay_status.get("gui_overlay_reason"):
                log(f"[WARN] GUI status overlay not active (reason={overlay_status.get('gui_overlay_reason')}).")
        if not bool(overlay_status.get("vt_enabled")):
            log("[WARN] ANSI VT mode is disabled; WARN/ERROR/TIMER colors may not render.")
        elif overlay_status.get("vt_reason"):
            log(f"[INFO] ANSI VT enabled via fallback ({overlay_status.get('vt_reason')}).")
    recorder_proc: Optional[subprocess.Popen] = None
    cdp_browser_proc: Optional[subprocess.Popen] = None
    quiz_server_proc: Optional[subprocess.Popen] = None
    cdp_endpoint_ready = False
    recorder_stack_enabled = str(os.environ.get("FULLBOT_ENABLE_RECORDER_STACK", "1") or "1").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    if not recorder_stack_enabled:
        args.disable_recorder = True
        log("[INFO] Recorder stack disabled (FULLBOT_ENABLE_RECORDER_STACK=0).")
    recorder_args: List[str] = _normalize_recorder_args(args.recorder_args)
    dom_fallback_on_demand = str(os.environ.get("FULLBOT_DOM_FALLBACK_ON_DEMAND", "1") or "1").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    if args.quiz_mode and (not _has_flag(recorder_args, "--quiz-mode")):
        recorder_args.append("--quiz-mode")
    if args.quiz_mode and (not _has_flag(recorder_args, "--quiz")):
        recorder_args.append("--quiz")
    if args.quiz_mode and (not _has_flag(recorder_args, "--url")):
        recorder_args.extend(["--url", str(args.quiz_lock_url_prefix or QUIZ_SERVER_URL)])
    if (not _has_flag(recorder_args, "--url")):
        recorder_args.extend(["--url", str(os.environ.get("FULLBOT_DOM_FALLBACK_URL", QUIZ_SERVER_URL) or QUIZ_SERVER_URL)])

    trigger_event = threading.Event()
    command_queue: "queue.Queue[str]" = queue.Queue()
    hotkey_listener = None
    early_exit_listener = None
    console_p_mode = False
    update_overlay_status("Initializing pipeline...")
    def _soft_exit_only() -> None:
        with contextlib.suppress(Exception):
            log("[INFO] Soft exit: keeping region_grow daemon alive.")

    def _full_exit_all() -> None:
        with contextlib.suppress(Exception):
            _stop_region_grow_daemon_mod(log=log)

    # Start as early as possible so `}` works even during OCR warmup/bootstrap.
    early_exit_listener = _start_early_exit_listener_mod(
        log=log,
        soft_exit_fn=_soft_exit_only,
        full_exit_fn=_full_exit_all,
    )
    click_monitor_enabled = str(os.environ.get("FULLBOT_CLICK_MONITOR_ENABLED", "1") or "1").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    click_monitor = None
    if click_monitor_enabled:
        click_monitor = start_screen_click_monitor(out_dir=CLICKS_ON_SCREEN_DIR, log=log)
        globals()["_click_monitor"] = click_monitor
    deferred_debug_worker = create_deferred_debug_worker(
        root=ROOT,
        run_region_annotation=run_region_annotation,
        log=log,
    )
    deferred_debug_worker.start()
    globals()["_deferred_debug_worker"] = deferred_debug_worker
    quiz_server_proc = start_quiz_server()

    if not args.disable_recorder:
        if not dom_fallback_on_demand:
            cdp_browser_proc, cdp_endpoint_ready = start_cdp_browser_for_recorder()
            if cdp_endpoint_ready:
                if not _has_flag(recorder_args, "--cdp-endpoint"):
                    recorder_args.extend(["--cdp-endpoint", f"http://127.0.0.1:{RECORDER_CDP_PORT}"])
                if not _has_flag(recorder_args, "--connect-existing"):
                    recorder_args.append("--connect-existing")
                if not _has_flag(recorder_args, "--user-data-dir"):
                    recorder_args.extend(["--user-data-dir", str(RECORDER_PROFILE_DIR)])
            recorder_proc = start_ai_recorder(recorder_args)
            globals()["_recorder_proc_ref"] = recorder_proc
            if args.quiz_mode:
                update_overlay_status("Waiting for quiz page lock...")
                quiz_lock_timeout_s = float(os.environ.get("FULLBOT_QUIZ_PAGE_LOCK_TIMEOUT", "1.0") or "1.0")
                _wait_for_quiz_page_lock(args.quiz_lock_url_prefix or QUIZ_SERVER_URL, timeout_s=quiz_lock_timeout_s)
        else:
            log("[INFO] DOM fallback recorder mode: on-demand (lazy start).")
            # Without recorder, still lock active tab by URL via CDP in quiz mode.
            if args.quiz_mode:
                cdp_browser_proc, cdp_endpoint_ready = start_cdp_browser_for_recorder()
                if cdp_endpoint_ready:
                    _ensure_active_tab_via_cdp(str(args.quiz_lock_url_prefix or QUIZ_SERVER_URL))
                else:
                    log("[WARN] CDP endpoint unavailable: cannot lock active tab without recorder.")
    elif args.quiz_mode:
        # Recorder fully disabled: keep quiz tab lock via CDP only.
        cdp_browser_proc, cdp_endpoint_ready = start_cdp_browser_for_recorder()
        if cdp_endpoint_ready:
            _ensure_active_tab_via_cdp(str(args.quiz_lock_url_prefix or QUIZ_SERVER_URL))
        else:
            log("[WARN] CDP endpoint unavailable: cannot lock active tab (recorder disabled).")

    def _ensure_dom_fallback_ensurer(reason: str = "") -> bool:
        nonlocal recorder_proc, cdp_browser_proc, cdp_endpoint_ready, recorder_args
        os.environ["FULLBOT_DOM_FALLBACK_ACTIVE"] = "1"
        if args.disable_recorder:
            log("[DOM FALLBACK] recorder disabled by args; fallback unavailable.")
            return False
        if recorder_proc is not None and recorder_proc.poll() is None:
            return True
        if not cdp_endpoint_ready:
            cdp_browser_proc, cdp_endpoint_ready = start_cdp_browser_for_recorder()
            if cdp_endpoint_ready:
                if not _has_flag(recorder_args, "--cdp-endpoint"):
                    recorder_args.extend(["--cdp-endpoint", f"http://127.0.0.1:{RECORDER_CDP_PORT}"])
                if not _has_flag(recorder_args, "--connect-existing"):
                    recorder_args.append("--connect-existing")
                if not _has_flag(recorder_args, "--user-data-dir"):
                    recorder_args.extend(["--user-data-dir", str(RECORDER_PROFILE_DIR)])
        log(f"[DOM FALLBACK] enabling recorder (reason={reason or 'runtime_request'})")
        recorder_proc = start_ai_recorder(recorder_args)
        globals()["_recorder_proc_ref"] = recorder_proc
        state_ref = globals().get("_main_state_ref")
        if isinstance(state_ref, dict):
            state_ref["recorder_proc"] = recorder_proc
        if recorder_proc is None:
            log("[DOM FALLBACK] recorder start failed.")
            return False
        t0 = time.time()
        deadline = t0 + float(os.environ.get("FULLBOT_DOM_FALLBACK_WAIT_S", "6.0") or 6.0)
        while time.time() < deadline:
            if CURRENT_CONTROLS_PATH.exists() and CURRENT_CONTROLS_PATH.stat().st_mtime >= (t0 - 1.0):
                log("[DOM FALLBACK] recorder ready (current_controls.json updated).")
                return True
            if CURRENT_PAGE_PATH.exists() and CURRENT_PAGE_PATH.stat().st_mtime >= (t0 - 1.0):
                log("[DOM FALLBACK] recorder ready (current_page.json updated).")
                return True
            time.sleep(0.15)
        log("[DOM FALLBACK] recorder started, waiting for fresh DOM snapshot timed out.")
        return True

    globals()["_dom_fallback_ensurer"] = _ensure_dom_fallback_ensurer
    minimize_console = str(os.environ.get("FULLBOT_MINIMIZE_CONSOLE_ON_START", "1") or "1").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    if minimize_console and args.quiz_mode:
        with contextlib.suppress(Exception):
            _minimize_console_window()

    # Upewnij siŽt, ‘•e control_agent jest uruchomiony jeszcze PRZED pierwszym
    # komunikatem "Waiting for hotkey 'P'...", ‘•eby pierwsze wciŽ>niŽtcie P
    # mia‘'o ju‘• gotowego agenta do przyjŽtcia hover path.
    control_agent_proc: Optional[subprocess.Popen] = None
    if not args.safe_test:
        control_agent_proc = ensure_control_agent(CONTROL_AGENT_PORT)

    rg_exec_mode = str(os.environ.get("FULLBOT_REGION_GROW_EXEC_MODE", "daemon") or "daemon").strip().lower()
    daemon_alive = bool(rg_exec_mode == "daemon" and _is_region_grow_daemon_alive_mod())
    # Jednorazowy warm-up OCR przed pierwszą iteracją, żeby podczas
    # naciśnięcia 'P' screenshot był robiony od razu na aktualnym ekranie.
    skip_shared_ocr_warmup = bool(
        daemon_alive or (args.quiz_mode and not _current_interpreter_has_gpu_ocr())
    )
    if skip_shared_ocr_warmup:
        os.environ["FULLBOT_OCR_FALLBACK_ON_FAIL"] = "0"
        if daemon_alive:
            log("[INFO] Shared OCR warmup skipped: region_grow daemon already alive.")
            update_overlay_status("OCR warmup skipped (daemon already alive).")
        else:
            log("[INFO] Skipping shared OCR warmup in quiz mode: current interpreter has no GPU OCR runtime.")
            update_overlay_status("OCR warmup skipped (GPU subprocess only).")
    else:
        update_overlay_status("Warming OCR models...")
        warm_ocr_once()
        update_overlay_status("OCR ready. Waiting for pipeline start.")
    bootstrap_on_start = str(os.environ.get("FULLBOT_REGION_GROW_BOOTSTRAP_ON_START", "1") or "1").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    if bootstrap_on_start and (not daemon_alive):
        update_overlay_status("Bootstrapping region_grow worker...")
        _ = bootstrap_region_grow_worker()
        update_overlay_status("region_grow worker ready.")
    elif bootstrap_on_start and daemon_alive:
        log("[INFO] region_grow bootstrap skipped: daemon already alive.")
    if DEBUG_MODE:
        debug(f"Args: interval={args.interval} loop_count={args.loop_count} auto={args.auto} disable_recorder={args.disable_recorder} left={args.left} debug={args.debug}")
        debug(f"Paths: raw={SCREENSHOT_DIR} hover_input_current={HOVER_INPUT_CURRENT_DIR} hover_output_current={HOVER_OUTPUT_CURRENT_DIR}")

    try:
        # Uruchomienie prostego nasłuchiwacza skrótów klawiszowych dla losowego ruchu myszy w osobnym procesie.
        listener_script_path = str(ROOT / "scripts" / "hotkey_listener.py")
        cmd = [sys.executable, listener_script_path]
        
        # W systemie Windows użyj flagi CREATE_NO_WINDOW, aby ukryć okno konsoli dla nowego procesu.
        creation_flags = 0
        if os.name == "nt":
            creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)

        subprocess.Popen(cmd, creationflags=creation_flags)
        log("[INFO] Uruchomiono nasłuchiwacz skrótu klawiszowego '?' dla losowego ruchu myszy.")
    except Exception as e:
        log(f"[ERROR] Nie udało się uruchomić nasłuchiwacza skrótu klawiszowego '?' dla losowego ruchu myszy: {e}")

    if not args.auto:
        if early_exit_listener is not None:
            with contextlib.suppress(Exception):
                early_exit_listener.stop()
            early_exit_listener = None
        hotkey_listener = start_hotkey_listener(trigger_event, command_queue)
        if hotkey_listener is None:
            console_p_mode = True
            update_overlay_status("P mode active (console). Press P for one iteration.")
        else:
            # Environment-safe fallback: in advanced debug start first iteration automatically.
            autostart_first = str(
                os.environ.get(
                    "FULLBOT_AUTOSTART_FIRST_ITERATION",
                    "1" if globals()["ADVANCED_DEBUG_MODE"] else "0",
                )
                or "0"
            ).strip().lower() in {"1", "true", "yes", "on"}
            if autostart_first:
                trigger_event.set()
                log("[INFO] Auto-starting first iteration (FULLBOT_AUTOSTART_FIRST_ITERATION).")
                update_overlay_status("Auto-starting first iteration.")
    else:
        update_overlay_status("Auto mode active.")
                            
    log(
        f"[INFO] Pipeline start (interval={args.interval}s"
        + (f", max_loops={args.loop_count}" if args.loop_count else ", continuous")
        + ")"
    )

    state = {
        "recorder_proc": recorder_proc,
        "cdp_browser_proc": cdp_browser_proc,
        "control_agent_proc": control_agent_proc,
        "console_p_mode": bool(console_p_mode),
        "debug_mode": bool(DEBUG_MODE),
    }
    globals()["_main_state_ref"] = state

    try:
        _run_loop_controller(
            args=args,
            trigger_event=trigger_event,
            command_queue=command_queue,
            state=state,
            pipeline_iteration=pipeline_iteration,
            drain_manual_commands=lambda cmd_queue, a, rec: _drain_manual_commands(cmd_queue, a, rec),
            ensure_control_agent=lambda: ensure_control_agent(CONTROL_AGENT_PORT),
            cancel_hover_fallback_timer=cancel_hover_fallback_timer,
            wait_for_p_in_console=_wait_for_p_in_console,
            log=log,
            debug=debug,
            update_overlay_status=update_overlay_status,
        )
    except KeyboardInterrupt:
        log("[INFO] Stopped by user.")
    finally:
        recorder_proc = state.get("recorder_proc") or globals().get("_recorder_proc_ref")
        cdp_browser_proc = state.get("cdp_browser_proc")
        control_agent_proc = state.get("control_agent_proc")
        globals()["_dom_fallback_ensurer"] = None
        globals()["_main_state_ref"] = None
        worker = globals().get("_deferred_debug_worker")
        if worker is not None:
            drain_on_exit = str(os.environ.get("FULLBOT_DEBUG_DEFERRED_DRAIN_ON_EXIT", "1") or "1").strip().lower() in {
                "1",
                "true",
                "yes",
                "on",
            }
            with contextlib.suppress(Exception):
                worker.stop(drain=drain_on_exit, timeout=15.0)
            globals()["_deferred_debug_worker"] = None
        monitor = globals().get("_click_monitor")
        if monitor is not None:
            with contextlib.suppress(Exception):
                monitor.stop()
            globals()["_click_monitor"] = None
        stop_process(recorder_proc)
        # Keep CDP browser alive between runs (do not stop here).
        if control_agent_proc is not None:
            stop_process(control_agent_proc)
        if hotkey_listener is not None:
            try:
                hotkey_listener.stop()
            except Exception:
                pass
        if early_exit_listener is not None:
            with contextlib.suppress(Exception):
                early_exit_listener.stop()
        cancel_hover_fallback_timer()
        overlay = globals().get("_status_overlay")
        if overlay is not None and hasattr(overlay, "close"):
            with contextlib.suppress(Exception):
                overlay.close()


if __name__ == "__main__":
    with contextlib.suppress(Exception):
        register_main_launch(ROOT)
    main()
