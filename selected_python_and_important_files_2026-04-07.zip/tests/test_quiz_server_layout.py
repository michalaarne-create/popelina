from __future__ import annotations

import sys
from pathlib import Path
import unittest

TESTS_ROOT = Path(__file__).resolve().parents[2]
PACKAGE_ROOT = TESTS_ROOT / "popelina_github"
if str(TESTS_ROOT) not in sys.path:
    sys.path.insert(0, str(TESTS_ROOT))
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from popelina_github.quiz import test_quiz_server as quiz_server


class QuizServerLayoutTests(unittest.TestCase):
    def test_question_page_keeps_quiz_markup_and_adds_sidebar(self) -> None:
        qt = quiz_server.BANK[0]
        html = quiz_server._question_page(qt, 1, reset=False).decode("utf-8")
        self.assertIn('aria-label="Panel boczny"', html)
        self.assertIn("Panel boczny", html)
        self.assertIn("id='qid'", html)
        self.assertIn("class='opt'", html)
        self.assertIn("id='next'", html)

    def test_index_page_keeps_sidebar_and_quiz_links(self) -> None:
        html = quiz_server._index_page().decode("utf-8")
        self.assertIn('aria-label="Panel boczny"', html)
        self.assertIn("Test Quiz Server", html)
        self.assertIn("href='/t/1/1'", html)
        self.assertIn("href='/t/1/1?reset=1'", html)


if __name__ == "__main__":
    unittest.main()
