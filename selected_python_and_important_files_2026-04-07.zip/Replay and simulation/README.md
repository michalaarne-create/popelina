# Replay and simulation

Ten katalog zbiera narzędzia do odtwarzania i porównywania zapisanych artefaktów runtime bez uruchamiania przeglądarki.

Zawartość:

- `artifact_replay_runner.py` odtwarza planner na bazie zapisanych `screen_state.json` i `decision.json`.
- `session_bundle_packer.py` pakuje jedną sesję do przenośnego bundle z manifestem i komendą reprodukcji.
- `counterfactual_action_simulator.py` porównuje kilka alternatywnych planów dla tego samego `screen_state`.
- `decision_diff_viewer.py` pokazuje różnice między dwiema decyzjami brain dla tego samego lub podobnego artefaktu.
- `replay_lib.py` zawiera wspólne helpery używane przez powyższe narzędzia.

Przykłady:

```powershell
python "popelina_github\\Replay and simulation\\artifact_replay_runner.py" --run-dir "popelina_github\\data\\auto_main\\runs\\20260325_225304_935391_t03_q01"
python "popelina_github\\Replay and simulation\\session_bundle_packer.py" --run-dir "popelina_github\\data\\auto_main\\runs\\20260325_225304_935391_t03_q01"
python "popelina_github\\Replay and simulation\\counterfactual_action_simulator.py" --decision-json "popelina_github\\data\\auto_main\\runs\\20260325_225304_935391_t03_q01\\iter_001\\decision.json"
python "popelina_github\\Replay and simulation\\decision_diff_viewer.py" --left "a\\decision.json" --right "b\\decision.json"
```
