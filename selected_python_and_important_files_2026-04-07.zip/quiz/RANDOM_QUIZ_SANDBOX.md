# Random Quiz Sandbox + Auto Dataset

## Co to robi
- `random_quiz_sandbox.py`: generuje mocno zrandomizowane quizy WWW (style, odstepy, kolory, layout, typy kontrolek).
- `build_random_www_quiz_dataset.py`: automatycznie buduje dataset (html + label + screenshot + manifest), bez recznego screenowania.

## 1) Podglad sandboxa (serwer)
```powershell
.\.venv312\Scripts\python.exe .\quiz\random_quiz_sandbox.py --count 2000 --seed 20260312 --port 8010
```
- lista: `http://127.0.0.1:8010/`
- manifest JSON: `http://127.0.0.1:8010/api/manifest`

## 1b) Tylko eksport manifestu (bez uruchamiania serwera)
```powershell
.\.venv312\Scripts\python.exe .\quiz\random_quiz_sandbox.py --count 2000 --seed 20260312 --export-manifest .\data\benchmarks\random_www_quiz\sandbox_manifest.json --export-only
```

## 2) Auto dataset (screenshot + labels)
```powershell
.\.venv312\Scripts\python.exe .\quiz\build_random_www_quiz_dataset.py --count 5000 --seed 20260312 --headless 1 --timeout-ms 12000 --out-dir .\data\benchmarks\random_www_quiz
```

## 3) Auto dataset przez juz odpalona przegladarke CDP
```powershell
.\.venv312\Scripts\python.exe .\quiz\build_random_www_quiz_dataset.py --count 5000 --seed 20260312 --cdp-endpoint http://127.0.0.1:9222 --out-dir .\data\benchmarks\random_www_quiz
```

## 4) Tylko HTML + labels (bez screenshotow)
```powershell
.\.venv312\Scripts\python.exe .\quiz\build_random_www_quiz_dataset.py --count 5000 --seed 20260312 --html-only --out-dir .\data\benchmarks\random_www_quiz
```

## Struktura outputu
- `images/*.png` - screenshoty
- `labels/*.json` - etykiety (global_type, block_types, pytania, odpowiedzi, bbox z DOM renderu)
- `html/*.html` - zrenderowane strony
- `manifests/dataset_manifest.jsonl` - glowny manifest datasetu
- `manifests/dataset_summary.json` - statystyki generacji
