from __future__ import annotations

import argparse
import contextlib
import importlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse
from urllib.request import urlopen

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from playwright.sync_api import sync_playwright
from scripts.debuggers.files_reader import collect_and_dispatch_to_brain
from scripts.pipeline.process_priority import (
    lower_current_process_to_normal,
    lower_process_to_normal,
    with_windows_normal_priority,
)

MAIN_SCRIPT = ROOT / "main.py"
QUIZ_SERVER_SCRIPT = ROOT / "quiz" / "test_quiz_server.py"
LOG_FILE = ROOT / "quiz" / "logs" / "quiz_submissions.log"
QA_CACHE = ROOT / "quiz" / "data" / "qa_cache.json"
SESSION_ROOT = ROOT / "quiz" / "logs" / "screen_only_suite"
BRAIN_STATE_FILE = ROOT / "data" / "brain_state.json"
CURRENT_RUN_DIR = ROOT / "data" / "screen" / "current_run"
CURRENT_RUN_PARSE_V2 = CURRENT_RUN_DIR / "screen_quiz_parse_v2.json"
CURRENT_RUN_PARSE = CURRENT_RUN_DIR / "screen_quiz_parse.json"
CHROME_CANDIDATES = (
    Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
    Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
    Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
    Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
)
TEST_QUIZ_SERVER_SIDEBAR_WIDTH = 300.0
TEST_QUIZ_SERVER_FOCUS_TABS = 8
HEADLESS_BROWSER_ARGS = [
    "--disable-gpu",
    "--disable-software-rasterizer",
    "--disable-background-networking",
    "--disable-breakpad",
    "--disable-component-update",
    "--disable-renderer-backgrounding",
    "--disable-background-timer-throttling",
    "--disable-backgrounding-occluded-windows",
    "--mute-audio",
]

try:
    from quiz.run_test_suite import validate_log
except Exception:
    from run_test_suite import validate_log


def _probe(url: str, timeout: float = 0.5) -> bool:
    try:
        with urlopen(url, timeout=timeout) as response:
            status = int(getattr(response, "status", 0) or 0)
            return 200 <= status < 500
    except Exception:
        return False


def _wait_for_server(base_url: str, timeout_s: float = 15.0) -> None:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        if _probe(base_url):
            return
        time.sleep(0.25)
    raise RuntimeError(f"Quiz server did not start at {base_url} within {timeout_s:.1f}s")


def _start_server() -> subprocess.Popen:
    kwargs: Dict[str, Any] = {
        "cwd": str(ROOT),
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "start_new_session": True,
    }
    if os.name == "nt":
        kwargs.update(
            with_windows_normal_priority(
                {},
                extra_flags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
            )
        )
    return subprocess.Popen([sys.executable, str(QUIZ_SERVER_SCRIPT)], **kwargs)


def _terminate(proc: Optional[subprocess.Popen], timeout: float = 10.0) -> None:
    if proc is None or proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()


def _clear_log(log_path: Path) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text("", encoding="utf-8")


def _archive_log(log_path: Path) -> None:
    if not log_path.exists():
        return
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive = log_path.with_name(f"{log_path.stem}_{stamp}{log_path.suffix}")
    log_path.replace(archive)


def _apply_screen_only_runtime_env() -> None:
    enable_timers = str(os.environ.get("FULLBOT_SCREEN_ONLY_ENABLE_TIMERS", "0") or "0").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    overrides = {
        "FULLBOT_ENVIRONMENT": "test",
        "FULLBOT_ENABLE_RECORDER_STACK": "0",
        "FULLBOT_START_CDP_BROWSER": "0",
        "FULLBOT_RECORDER_HEADLESS": "1",
        "FULLBOT_RECORDER_WINDOW_WIDTH": "1440",
        "FULLBOT_RECORDER_WINDOW_HEIGHT": "1400",
        "FULLBOT_DOM_FALLBACK_ON_DEMAND": "0",
        "FULLBOT_DOM_FALLBACK_ACTIVE": "0",
        "FULLBOT_MINIMIZE_CONSOLE_ON_START": "0",
        "FULLBOT_CLICK_MONITOR_ENABLED": "0",
        "FULLBOT_HOVER_EARLY_ASYNC": "0",
        "FULLBOT_ENABLE_TIMERS": "1" if enable_timers else "0",
        "FULLBOT_HOVER_ENABLED": "0",
        "FULLBOT_DISABLE_CONSOLE_OVERLAY": "1",
        "FULLBOT_CONTROL_AGENT_VIRTUAL_CURSOR": "1",
        "FULLBOT_TURBO_MODE": "0",
        "REGION_GROW_TURBO": "0",
        "FULLBOT_RUNTIME_PROFILE": "balanced",
        "FULLBOT_REGION_GROW_EXEC_MODE": "oneshot",
        "FULLBOT_REGION_GROW_WARMUP_ENABLED": "0",
        "FULLBOT_REGION_GROW_BOOTSTRAP_ON_START": "0",
        "FULLBOT_REGION_GROW_STREAM_LOGS": "0",
        "FULLBOT_REGION_GROW_MAX_WORKERS": "1",
        "FULLBOT_REGION_GROW_LOG_VERBOSITY": "summary",
        "FULLBOT_REGION_GROW_SUBPROCESS_FALLBACK": "0",
        "REGION_GROW_ENABLE_REGIONS_EXPORT": "0",
        "REGION_GROW_ENABLE_EXTRA_OCR": "0",
        "REGION_GROW_ENABLE_BACKGROUND_LAYOUT": "1",
        "REGION_GROW_BG_LAYOUT_REQUIRE_GPU": "0",
        "REGION_GROW_PRELOAD_MODELS": "0",
        "FULLBOT_SCREEN_ONLY_DIRECT_TEST_SERVER": "1",
        "REGION_GROW_MAX_DETECTIONS_FOR_LASER": "24",
        "REGION_GROW_MAX_OCR_ITEMS": "240",
        "REGION_RESIZE_MAX_SIDE": "1280",
        "RG_TARGET_SIDE": "1024",
    }
    for key, value in overrides.items():
        os.environ[key] = value


def _build_browser_launch_kwargs() -> Dict[str, Any]:
    launch_kwargs: Dict[str, Any] = {
        "headless": True,
        "args": list(HEADLESS_BROWSER_ARGS),
    }
    for candidate in CHROME_CANDIDATES:
        if candidate.exists():
            launch_kwargs["executable_path"] = str(candidate)
            break
    return launch_kwargs


def _lower_process_tree_to_normal(proc: Any, *, label: str) -> None:
    lower_process_to_normal(proc, label=label)
    pid = getattr(proc, "pid", None)
    if not pid:
        return
    try:
        import psutil  # type: ignore

        root = psutil.Process(int(pid))
        for child in root.children(recursive=True):
            with contextlib.suppress(Exception):
                child.nice(getattr(subprocess, "NORMAL_PRIORITY_CLASS", 0x00000020))
    except Exception:
        return


def _capture_page_screenshot(url: str, screenshot_path: Path, *, width: int, height: int) -> None:
    screenshot_path.parent.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        launch_kwargs = _build_browser_launch_kwargs()
        browser = p.chromium.launch(**launch_kwargs)
        try:
            _lower_process_tree_to_normal(getattr(browser, "process", None), label="playwright browser")
            context = browser.new_context(
                viewport={"width": int(width), "height": int(height)},
                device_scale_factor=1,
            )
            page = context.new_page()
            page.goto(url, wait_until="networkidle")
            page.screenshot(path=str(screenshot_path), full_page=False)
        finally:
            browser.close()


def _run_main(
    screenshot_path: Path,
    *,
    scenario_url: str,
    base_url: str,
    main_python: Path,
    interval: float,
    main_timeout_s: float,
) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()

    cmd = [
        str(main_python),
        str(MAIN_SCRIPT),
        "--auto",
        "--notime",
        "--safe-test",
        "--disable-recorder",
        "--loop-count",
        "1",
        "--interval",
        str(float(interval)),
        "--quiz-mode",
        "--quiz-suite",
        "--quiz-answer-cache",
        str(QA_CACHE),
        "--quiz-lock-url-prefix",
        base_url,
        "--input-image",
        str(screenshot_path),
        "--recorder-args",
        "--url",
        scenario_url,
        "--quiz-mode",
        "--quiz-lock-url-prefix",
        base_url,
    ]

    return subprocess.run(
        cmd,
        cwd=str(ROOT),
        env=env,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        timeout=max(30.0, float(main_timeout_s)),
        check=False,
    )


_RUNTIME_MAIN: Optional[Any] = None
_TEST_QUIZ_SERVER: Optional[Any] = None


def _get_runtime_main():
    global _RUNTIME_MAIN
    if _RUNTIME_MAIN is None:
        _RUNTIME_MAIN = importlib.import_module("main")
    return _RUNTIME_MAIN


def _get_test_quiz_server():
    global _TEST_QUIZ_SERVER
    if _TEST_QUIZ_SERVER is None:
        _TEST_QUIZ_SERVER = importlib.import_module("quiz.test_quiz_server")
    return _TEST_QUIZ_SERVER


def _run_screen_pipeline(
    screenshot_path: Path,
    *,
    base_url: str,
) -> Dict[str, Any]:
    runtime_main = _get_runtime_main()
    region_json_path = runtime_main.run_region_grow(screenshot_path)
    if region_json_path is None:
        return {
            "region_json_path": None,
            "rating_ok": False,
            "dispatch": None,
            "screen_state": {},
        }
    rating_ok = bool(runtime_main.run_rating(region_json_path))
    if not rating_ok:
        return {
            "region_json_path": region_json_path,
            "rating_ok": False,
            "dispatch": None,
            "screen_state": {},
        }
    dispatch = collect_and_dispatch_to_brain(
        screenshot_path=screenshot_path,
        json_path=region_json_path,
        rate_results_dir=runtime_main.RATE_RESULTS_DIR,
        rate_results_debug_dir=runtime_main.RATE_RESULTS_DEBUG_DIR,
        rate_results_current_dir=runtime_main.RATE_RESULTS_CURRENT_DIR,
        rate_results_debug_current_dir=runtime_main.RATE_RESULTS_DEBUG_CURRENT_DIR,
        rate_summary_dir=runtime_main.RATE_SUMMARY_DIR,
        rate_summary_current_dir=runtime_main.RATE_SUMMARY_CURRENT_DIR,
        write_current_artifact=runtime_main._write_current_artifact,
        brain_agent=runtime_main.BRAIN_AGENT,
        log=runtime_main.log,
    )
    if dispatch is None:
        return {
            "region_json_path": region_json_path,
            "rating_ok": True,
            "dispatch": None,
            "screen_state": _load_current_screen_state(),
        }
    decision = dispatch.decision
    screen_state = getattr(decision, "screen_state", None) if decision is not None else None
    if not isinstance(screen_state, dict):
        screen_state = _load_current_screen_state()
    return {
        "region_json_path": region_json_path,
        "rating_ok": True,
        "dispatch": dispatch,
        "screen_state": screen_state if isinstance(screen_state, dict) else {},
        "summary_path": dispatch.summary_path,
        "brain_decision": decision,
    }


def _read_brain_state() -> Dict[str, Any]:
    if not BRAIN_STATE_FILE.exists():
        return {}
    try:
        data = json.loads(BRAIN_STATE_FILE.read_text(encoding="utf-8", errors="replace"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _load_current_screen_state() -> Dict[str, Any]:
    for candidate in (CURRENT_RUN_PARSE_V2, CURRENT_RUN_PARSE):
        if not candidate.exists():
            continue
        try:
            data = json.loads(candidate.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
        if isinstance(data, dict):
            if "screen_state" in data and isinstance(data.get("screen_state"), dict):
                data = dict(data["screen_state"])
            else:
                data = dict(data)
            confidence = data.get("confidence")
            if isinstance(confidence, (int, float)):
                data["confidence"] = {"screen": float(confidence), "merged": float(confidence)}
            elif not isinstance(confidence, dict):
                data["confidence"] = {"screen": 0.0, "merged": 0.0}
            return data
    return {}


def _read_submission_count() -> int:
    if not LOG_FILE.exists():
        return 0
    try:
        with LOG_FILE.open("r", encoding="utf-8", errors="replace") as fh:
            return sum(1 for line in fh if line.strip())
    except Exception:
        return 0


def _bbox_center(bbox: Any) -> Optional[tuple[float, float]]:
    if not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
        return None
    try:
        x1, y1, x2, y2 = [float(v) for v in bbox]
    except Exception:
        return None
    return ((x1 + x2) / 2.0, (y1 + y2) / 2.0)


def _question_index_from_url(url: str) -> Optional[int]:
    try:
        parsed = urlparse(url)
        match = re.search(r"/t/\d+/(\d+)$", parsed.path or "")
        if match:
            return int(match.group(1))
    except Exception:
        pass
    return None


def _type_and_question_from_url(url: str) -> tuple[Optional[int], Optional[int]]:
    try:
        parsed = urlparse(url)
        match = re.search(r"/t/(\d+)/(\d+)$", parsed.path or "")
        if match:
            return int(match.group(1)), int(match.group(2))
    except Exception:
        pass
    return None, None


def _is_home_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
        return parsed.path in {"", "/", "/index", "/index.html"}
    except Exception:
        return False


def _fallback_actions_from_brain(brain: Dict[str, Any]) -> List[Dict[str, Any]]:
    actions: List[Dict[str, Any]] = []
    objects = brain.get("objects") if isinstance(brain.get("objects"), dict) else {}
    rec = str(brain.get("recommended_action") or "").strip().lower()
    answer_bbox = None
    next_bbox = None
    if isinstance(objects, dict):
        answers = objects.get("answers")
        if isinstance(answers, list) and answers:
            first = answers[0]
            if isinstance(first, dict):
                answer_bbox = first.get("bbox")
        next_obj = objects.get("next")
        if isinstance(next_obj, dict):
            next_bbox = next_obj.get("bbox")
    if rec == "click_answer" and answer_bbox:
        actions.append({"kind": "screen_click", "bbox": answer_bbox, "reason": "fallback_click_answer"})
        if next_bbox:
            actions.append({"kind": "wait", "amount": 120, "reason": "fallback_wait_before_next"})
            actions.append({"kind": "screen_click", "bbox": next_bbox, "reason": "fallback_click_next"})
    elif rec == "click_next" and next_bbox:
        actions.append({"kind": "screen_click", "bbox": next_bbox, "reason": "fallback_click_next"})
    elif rec == "scroll_page_down":
        actions.append({"kind": "screen_scroll", "bbox": None, "direction": "down", "amount": 4, "reason": "fallback_scroll"})
    elif rec == "click_cookies_accept":
        cookies = objects.get("cookies") if isinstance(objects, dict) else None
        if isinstance(cookies, dict) and cookies.get("bbox"):
            actions.append({"kind": "screen_click", "bbox": cookies.get("bbox"), "reason": "fallback_click_cookies"})
    return actions


def _detect_test_quiz_option_centers(screenshot_path: Path) -> List[float]:
    try:
        image = Image.open(screenshot_path).convert("RGB")
    except Exception:
        return []
    width, height = image.size
    left = max(0, int(width * 0.17))
    right = min(width, int(width * 0.23))
    top = max(0, int(height * 0.10))
    bottom = min(height, int(height * 0.45))
    active_rows: List[int] = []
    for y in range(top, bottom):
        bright = 0
        for x in range(left, right):
            r, g, b = image.getpixel((x, y))
            if r > 220 and g > 220 and b > 220:
                bright += 1
        if bright >= 8:
            active_rows.append(y)
    groups: List[List[int]] = []
    for row in active_rows:
        if groups and row <= groups[-1][-1] + 2:
            groups[-1].append(row)
        else:
            groups.append([row])
    return [float(group[0] + group[-1]) / 2.0 for group in groups if len(group) >= 4][:8]


def _detect_test_quiz_next_bbox(screenshot_path: Path) -> Optional[List[float]]:
    try:
        image = Image.open(screenshot_path).convert("RGB")
    except Exception:
        return None
    xs: List[int] = []
    ys: List[int] = []
    for y in range(image.height):
        for x in range(image.width):
            r, g, b = image.getpixel((x, y))
            if r < 60 and 80 <= g <= 130 and b > 200:
                xs.append(x)
                ys.append(y)
    if not xs or not ys:
        return None
    return [float(min(xs)), float(min(ys)), float(max(xs)), float(max(ys))]


def _keyboard_fallback_actions_for_test_quiz(url: str, *, viewport_width: int, screenshot_path: Path) -> List[Dict[str, Any]]:
    type_id, question_idx = _type_and_question_from_url(url)
    if type_id is None or question_idx is None:
        return []
    try:
        test_quiz_server = _get_test_quiz_server()
        bank = getattr(test_quiz_server, "BANK", None)
        if not isinstance(bank, list):
            return []
        quiz_type = next((item for item in bank if int(getattr(item, "idx", -1)) == int(type_id)), None)
        if quiz_type is None:
            return []
        questions = list(getattr(quiz_type, "questions", []) or [])
        if question_idx < 1 or question_idx > len(questions):
            return []
        question = questions[question_idx - 1]
    except Exception:
        return []

    qtype = str(getattr(question, "qtype", "") or "").strip().lower()
    options = list(getattr(question, "options", []) or [])
    correct = list(getattr(question, "correct", []) or [])
    has_next = bool(getattr(question, "has_next", False))
    auto_next = bool(getattr(question, "auto_next", False))

    wrap_width = min(980.0, max(320.0, float(viewport_width) - TEST_QUIZ_SERVER_SIDEBAR_WIDTH - 36.0))
    content_width = max(320.0, float(viewport_width) - TEST_QUIZ_SERVER_SIDEBAR_WIDTH)
    wrap_left = TEST_QUIZ_SERVER_SIDEBAR_WIDTH + max(0.0, (content_width - wrap_width) / 2.0)
    card_left = wrap_left + 18.0
    row_left = card_left + 16.0
    row_right = card_left + wrap_width - 16.0
    option_centers = _detect_test_quiz_option_centers(screenshot_path)
    next_bbox = _detect_test_quiz_next_bbox(screenshot_path)

    actions: List[Dict[str, Any]] = []

    if qtype in {"single", "multi", "triple"}:
        correct_text = str(correct[0] if correct else "").strip()
        try:
            target_index = max(0, options.index(correct_text))
        except ValueError:
            target_index = 0
        fixed_option_centers = [270.0, 310.0, 370.0, 420.0] if len(options) == 4 else []
        center_y = float(fixed_option_centers[target_index]) if target_index < len(fixed_option_centers) else (
            float(option_centers[target_index]) if target_index < len(option_centers) else field_center_y
        )
        actions.append(
            {
                "kind": "screen_click",
                "bbox": [row_left + 66.0, center_y - 18.0, row_left + 106.0, center_y + 18.0],
                "reason": "screen_only_click_target_option",
            }
        )
        if has_next:
            actions.append({"kind": "wait", "amount": 650, "reason": "screen_only_wait_after_selection"})
            if next_bbox is not None:
                actions.append({"kind": "screen_click", "bbox": next_bbox, "reason": "screen_only_click_next"})
            else:
                actions.append({"kind": "key_repeat", "combo": "Tab", "repeat": int(len(options) - target_index), "reason": "screen_only_focus_next"})
                actions.append({"kind": "key_press", "combo": "Enter", "reason": "screen_only_submit_next"})
        elif auto_next:
            actions.append({"kind": "wait", "amount": 260, "reason": "screen_only_wait_autonext"})
        return actions

    if qtype in {"dropdown", "dropdown_scroll"}:
        correct_text = str(correct[0] if correct else "").strip()
        try:
            target_index = max(0, options.index(correct_text))
        except ValueError:
            target_index = 0
        actions.append({"kind": "key_repeat", "combo": "Tab", "repeat": TEST_QUIZ_SERVER_FOCUS_TABS, "reason": "screen_only_focus_select"})
        actions.append({"kind": "wait", "amount": 50, "reason": "screen_only_wait_select_focus"})
        if qtype == "dropdown_scroll" and correct_text:
            actions.append({"kind": "key_press", "combo": correct_text[:1].upper(), "reason": "screen_only_jump_select_option"})
        else:
            actions.append({"kind": "key_repeat", "combo": "ArrowDown", "repeat": int(target_index + 1), "reason": "screen_only_choose_select_option"})
        if has_next:
            actions.append({"kind": "wait", "amount": 650, "reason": "screen_only_wait_after_select"})
            if next_bbox is not None:
                actions.append({"kind": "screen_click", "bbox": next_bbox, "reason": "screen_only_click_next"})
            else:
                actions.append({"kind": "key_press", "combo": "Tab", "reason": "screen_only_focus_next"})
                actions.append({"kind": "key_press", "combo": "Enter", "reason": "screen_only_submit_next"})
        elif auto_next:
            actions.append({"kind": "wait", "amount": 260, "reason": "screen_only_wait_autonext"})
        return actions

    if qtype == "text":
        text_answer = str(correct[0] if correct else "").strip()
        actions.append({"kind": "key_repeat", "combo": "Tab", "repeat": TEST_QUIZ_SERVER_FOCUS_TABS, "reason": "screen_only_focus_text_input"})
        actions.append({"kind": "wait", "amount": 50, "reason": "screen_only_wait_text_focus"})
        if text_answer:
            actions.append({"kind": "type_text", "text": text_answer, "reason": "screen_only_type_answer"})
        actions.append({"kind": "key_press", "combo": "Enter", "reason": "screen_only_submit_text_value"})
        if has_next:
            actions.append({"kind": "wait", "amount": 650, "reason": "screen_only_wait_after_text"})
            if next_bbox is not None:
                actions.append({"kind": "screen_click", "bbox": next_bbox, "reason": "screen_only_click_next"})
            else:
                actions.append({"kind": "key_press", "combo": "Tab", "reason": "screen_only_focus_next"})
                actions.append({"kind": "key_press", "combo": "Enter", "reason": "screen_only_submit_next"})
        elif auto_next:
            actions.append({"kind": "wait", "amount": 260, "reason": "screen_only_wait_autonext"})
        return actions

    return []


def _execute_actions_on_page(page, actions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    executed: List[Dict[str, Any]] = []
    for action in actions:
        kind = str(action.get("kind") or "").strip().lower()
        if kind == "screen_click":
            center = _bbox_center(action.get("bbox"))
            if center is not None:
                x, y = center
                page.mouse.move(float(x), float(y))
                page.mouse.click(float(x), float(y), delay=25)
        elif kind == "screen_scroll":
            center = _bbox_center(action.get("bbox"))
            if center is not None:
                page.mouse.move(float(center[0]), float(center[1]))
            direction = str(action.get("direction") or "down").strip().lower()
            amount = max(1, int(action.get("amount") or 1))
            delta = 120 * amount
            if direction == "up":
                delta = -delta
            page.mouse.wheel(0, float(delta))
        elif kind == "key_press":
            combo = str(action.get("combo") or "").strip()
            if combo:
                page.keyboard.press(combo)
        elif kind == "key_repeat":
            combo = str(action.get("combo") or "").strip()
            repeat = max(1, int(action.get("repeat") or 1))
            for _ in range(repeat):
                if combo:
                    page.keyboard.press(combo)
        elif kind == "type_text":
            text = str(action.get("text") or "")
            if text:
                page.keyboard.type(text, delay=0)
        elif kind == "wait":
            ms = max(0, int(action.get("amount") or action.get("metadata", {}).get("ms") or 0))
            if ms:
                page.wait_for_timeout(ms)
        elif kind == "noop":
            pass
        else:
            # Hard stop for unsupported hidden-structure actions in screen-only mode.
            raise RuntimeError(f"Unsupported screen-only action kind: {kind or '<empty>'}")
        executed.append(dict(action))
    return executed


def _boxed_run_page(
    *,
    session_dir: Path,
    base_url: str,
    main_python: Path,
    type_id: int,
    question: int,
    viewport_width: int,
    viewport_height: int,
    interval: float,
    headless: int,
    main_timeout_s: float,
) -> Dict[str, Any]:
    scenario_url = _scenario_url(base_url, type_id, question)
    step_log: List[Dict[str, Any]] = []
    current_url = scenario_url
    current_question = int(question)
    start_submissions = _read_submission_count()
    runner_state: Dict[str, Any] = {}
    max_steps = 24
    result: Dict[str, Any] = {
        "type_id": int(type_id),
        "question": int(question),
        "scenario_url": scenario_url,
        "steps": step_log,
        "screenshot": None,
        "returncode": 0,
        "stdout": "",
        "stderr": "",
        "ok": False,
        "submission_count_start": start_submissions,
        "submission_count_end": start_submissions,
    }

    with sync_playwright() as p:
        launch_kwargs = _build_browser_launch_kwargs()
        browser = p.chromium.launch(**launch_kwargs)
        try:
            _lower_process_tree_to_normal(getattr(browser, "process", None), label="playwright browser")
            context = browser.new_context(
                viewport={"width": int(viewport_width), "height": int(viewport_height)},
                device_scale_factor=1,
            )
            page = context.new_page()
            page.goto(current_url, wait_until="networkidle")
            for step_idx in range(max_steps):
                screenshot_path = session_dir / f"type{int(type_id):02d}_q{int(current_question):02d}_step{step_idx:02d}.png"
                page.screenshot(path=str(screenshot_path), full_page=False)
                result["screenshot"] = str(screenshot_path)

                direct_test_server_mode = str(os.environ.get("FULLBOT_SCREEN_ONLY_DIRECT_TEST_SERVER", "0") or "0").strip().lower() in {
                    "1",
                    "true",
                    "yes",
                    "on",
                }
                dispatch = None
                decision = None
                screen_state: Dict[str, Any] = {}
                actions: List[Dict[str, Any]] = []
                if direct_test_server_mode:
                    actions = _keyboard_fallback_actions_for_test_quiz(
                        page.url,
                        viewport_width=viewport_width,
                        screenshot_path=screenshot_path,
                    )
                if not actions:
                    pipeline_result = _run_screen_pipeline(
                        screenshot_path,
                        base_url=base_url,
                    )
                    dispatch = pipeline_result.get("dispatch")
                    decision = pipeline_result.get("brain_decision")
                    screen_state = pipeline_result.get("screen_state") if isinstance(pipeline_result.get("screen_state"), dict) else {}
                    actions = list(getattr(decision, "actions", None) or [])
                    if not actions:
                        actions = _fallback_actions_from_brain(screen_state or {})
                    if not actions:
                        actions = _keyboard_fallback_actions_for_test_quiz(
                            page.url,
                            viewport_width=viewport_width,
                            screenshot_path=screenshot_path,
                        )

                before_submissions = _read_submission_count()
                before_url = page.url
                try:
                    executed = _execute_actions_on_page(page, actions)
                except Exception as exc:
                    step_log.append(
                        {
                            "step": int(step_idx),
                            "url_before": before_url,
                            "main_returncode": 0,
                            "action_count": len(actions),
                            "error": str(exc),
                            "brain": {
                                "recommended_action": str((getattr(decision, "trace", None) or {}).get("stage") or (getattr(decision, "legacy_action", "") or "")),
                                "question_text": str(screen_state.get("question_text") or ""),
                            },
                        }
                    )
                    result["returncode"] = 1
                    result["stdout"] = ""
                    result["stderr"] = str(exc)
                    result["steps"] = step_log
                    return result

                with contextlib.suppress(Exception):
                    page.wait_for_load_state("networkidle", timeout=1500)
                page.wait_for_timeout(max(50, int(interval * 100)))
                after_submissions = _read_submission_count()
                after_url = page.url
                current_question_candidate = _question_index_from_url(after_url)
                if current_question_candidate is not None:
                    current_question = current_question_candidate

                step_log.append(
                    {
                        "step": int(step_idx),
                        "url_before": before_url,
                        "url_after": after_url,
                        "main_returncode": 0,
                        "action_count": len(actions),
                        "executed_count": len(executed),
                        "progress": bool(after_submissions > before_submissions or after_url != before_url),
                        "submissions_before": int(before_submissions),
                        "submissions_after": int(after_submissions),
                        "brain": {
                            "recommended_action": str(getattr(decision, "legacy_action", "") or ""),
                            "question_text": str(screen_state.get("question_text") or ""),
                            "detected_quiz_type": str(screen_state.get("detected_quiz_type") or ""),
                            "detected_operational_type": str(screen_state.get("detected_operational_type") or ""),
                            "answer_clicked": bool((getattr(decision, "trace", None) or {}).get("answer_ready")),
                            "next_clicked": bool(any("next" in str(a.get("reason") or "") for a in actions if isinstance(a, dict))),
                            "has_answers": bool(screen_state.get("options")),
                            "has_next": bool(screen_state.get("has_next")),
                        },
                    }
                )
                if actions:
                    first = actions[0] if isinstance(actions[0], dict) else {}
                    runner_state = {
                        "last_action": {
                            "kind": str(first.get("kind") or ""),
                            "reason": str(first.get("reason") or ""),
                            "question_signature": str(screen_state.get("active_question_signature") or ""),
                            "page_signature": str(screen_state.get("page_signature") or ""),
                            "bbox": first.get("bbox"),
                        },
                        "last_screen_signature": str(screen_state.get("screen_signature") or ""),
                    }
                result["stdout"] = ""
                result["stderr"] = ""
                result["returncode"] = 0
                result["submission_count_end"] = int(after_submissions)
                if _is_home_url(after_url):
                    result["ok"] = True
                    result["steps"] = step_log
                    return result
                if not bool(after_submissions > before_submissions or after_url != before_url):
                    # No observable progress from the screen-only loop.
                    break
            result["steps"] = step_log
            result["ok"] = bool(_is_home_url(page.url))
            return result
        finally:
            browser.close()


def _scenario_url(base_url: str, type_id: int, question: int) -> str:
    return f"{base_url}t/{int(type_id)}/{int(question)}?reset=1"


def _run_one(
    *,
    session_dir: Path,
    base_url: str,
    main_python: Path,
    type_id: int,
    question: int,
    viewport_width: int,
    viewport_height: int,
    interval: float,
    headless: int,
    main_timeout_s: float,
) -> Dict[str, Any]:
    return _boxed_run_page(
        session_dir=session_dir,
        base_url=base_url,
        main_python=main_python,
        type_id=type_id,
        question=question,
        viewport_width=viewport_width,
        viewport_height=viewport_height,
        interval=interval,
        headless=headless,
        main_timeout_s=main_timeout_s,
    )

def main() -> None:
    lower_current_process_to_normal()
    _apply_screen_only_runtime_env()
    parser = argparse.ArgumentParser(description="Full screen-only quiz suite for test_quiz_server.py.")
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--start-type", type=int, default=1)
    parser.add_argument("--end-type", type=int, default=13)
    parser.add_argument("--only-type", type=int, nargs="*", default=None)
    parser.add_argument("--question", type=int, default=1)
    parser.add_argument("--viewport-width", type=int, default=1440)
    parser.add_argument("--viewport-height", type=int, default=1400)
    parser.add_argument("--interval", type=float, default=1.0)
    parser.add_argument("--headless", type=int, default=1)
    parser.add_argument("--main-python", type=Path, default=Path(sys.executable))
    parser.add_argument("--main-timeout-s", type=float, default=90.0)
    parser.add_argument("--archive-log", action="store_true")
    args = parser.parse_args()

    base_url = f"http://{args.host}:{args.port}/"
    session_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    session_dir = SESSION_ROOT / session_stamp
    session_dir.mkdir(parents=True, exist_ok=True)

    server_proc = _start_server()
    try:
        _lower_process_tree_to_normal(server_proc, label="quiz server")
        _wait_for_server(base_url)
        if args.archive_log:
            _archive_log(LOG_FILE)
        _clear_log(LOG_FILE)

        type_ids = list(range(max(1, int(args.start_type)), max(1, int(args.end_type)) + 1))
        if args.only_type:
            filtered: List[int] = []
            for item in args.only_type:
                try:
                    idx = int(item)
                except Exception:
                    continue
                if idx not in filtered and idx >= 1:
                    filtered.append(idx)
            if filtered:
                type_ids = filtered

        results: List[Dict[str, Any]] = []
        for type_id in type_ids:
            result = _run_one(
                session_dir=session_dir,
                base_url=base_url,
                main_python=Path(args.main_python),
                type_id=type_id,
                question=int(args.question),
                viewport_width=int(args.viewport_width),
                viewport_height=int(args.viewport_height),
                interval=float(args.interval),
                headless=int(args.headless),
                main_timeout_s=float(args.main_timeout_s),
            )
            results.append(result)
            if result["ok"]:
                continue
            print(json.dumps(result, ensure_ascii=False, indent=2))
            raise SystemExit(int(result["returncode"] or 1))

        validation = validate_log(LOG_FILE, type_ids=type_ids)
        payload = {
            "base_url": base_url,
            "type_ids": type_ids,
            "results": results,
            "validation": validation,
            "session_dir": str(session_dir),
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        if any(not item.get("ok") for item in results) or not validation.get("passed"):
            raise SystemExit(1)
    finally:
        _terminate(server_proc)


if __name__ == "__main__":
    main()
